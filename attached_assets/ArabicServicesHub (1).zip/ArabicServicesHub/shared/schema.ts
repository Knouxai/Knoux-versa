import { pgTable, text, serial, timestamp, boolean, integer, jsonb, decimal } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

// Users table with premium membership support
export const users = pgTable("users", {
  id: serial("id").primaryKey(),
  email: text("email").notNull().unique(),
  username: text("username").notNull().unique(),
  password: text("password").notNull(),
  membershipTier: text("membership_tier").default("free"), // free, essential, professional, golden
  membershipExpiresAt: timestamp("membership_expires_at"),
  stripeCustomerId: text("stripe_customer_id"),
  subscriptionId: text("subscription_id"),
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
});

// Clipboard items for AI-powered clipboard management
export const clipboardItems = pgTable("clipboard_items", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").references(() => users.id),
  content: text("content").notNull(),
  contentType: text("content_type").notNull(), // text, url, code, password, image, file
  aiAnalysis: jsonb("ai_analysis"), // AI-generated tags, categories, security analysis
  isEncrypted: boolean("is_encrypted").default(false),
  isFavorite: boolean("is_favorite").default(false),
  accessCount: integer("access_count").default(0),
  lastAccessed: timestamp("last_accessed"),
  createdAt: timestamp("created_at").defaultNow(),
});

// Encrypted files for quantum encryption service
export const encryptedFiles = pgTable("encrypted_files", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").references(() => users.id),
  originalName: text("original_name").notNull(),
  encryptedName: text("encrypted_name").notNull(),
  fileSize: integer("file_size").notNull(),
  encryptionAlgorithm: text("encryption_algorithm").notNull(), // AES-256, AES-512, ChaCha20, Quantum-Safe
  encryptionKey: text("encryption_key").notNull(), // Encrypted with user's master key
  filePath: text("file_path").notNull(),
  isArVault: boolean("is_ar_vault").default(false),
  arUnlockCode: text("ar_unlock_code"), // For AR vault feature
  shareToken: text("share_token"), // For secure sharing
  expiresAt: timestamp("expires_at"), // For temporary files
  createdAt: timestamp("created_at").defaultNow(),
});

// Dark web monitoring alerts
export const darkWebAlerts = pgTable("dark_web_alerts", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").references(() => users.id),
  alertType: text("alert_type").notNull(), // email_breach, password_leak, credit_card_found, ssn_exposure
  monitoredData: text("monitored_data").notNull(), // The data being monitored
  breachSource: text("breach_source"), // Where the breach was detected
  description: text("description").notNull(),
  severity: text("severity").notNull(), // low, medium, high, critical
  recommendations: jsonb("recommendations"), // AI-generated security recommendations
  isResolved: boolean("is_resolved").default(false),
  resolvedAt: timestamp("resolved_at"),
  createdAt: timestamp("created_at").defaultNow(),
});

// Contact form submissions
export const contactSubmissions = pgTable("contact_submissions", {
  id: serial("id").primaryKey(),
  name: text("name").notNull(),
  email: text("email").notNull(),
  inquiryType: text("inquiry_type").notNull(),
  message: text("message").notNull(),
  priority: text("priority").default("normal"), // low, normal, high, urgent
  isResolved: boolean("is_resolved").default(false),
  responseMessage: text("response_message"),
  assignedTo: text("assigned_to"), // Support agent
  resolvedAt: timestamp("resolved_at"),
  createdAt: timestamp("created_at").defaultNow(),
});

// Payments and subscriptions
export const payments = pgTable("payments", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").references(() => users.id),
  stripePaymentIntentId: text("stripe_payment_intent_id").notNull(),
  amount: decimal("amount", { precision: 10, scale: 2 }).notNull(),
  currency: text("currency").default("usd"),
  membershipTier: text("membership_tier").notNull(),
  status: text("status").notNull(), // pending, succeeded, failed, canceled
  billingPeriod: text("billing_period").notNull(), // monthly, yearly
  createdAt: timestamp("created_at").defaultNow(),
});

// AI Security Analysis Logs
export const securityAnalysis = pgTable("security_analysis", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").references(() => users.id),
  analysisType: text("analysis_type").notNull(), // clipboard_scan, file_integrity, threat_detection
  targetData: text("target_data").notNull(),
  aiModel: text("ai_model").notNull(), // Which AI model performed analysis
  findings: jsonb("findings").notNull(), // Detailed analysis results
  riskScore: integer("risk_score").notNull(), // 0-100 risk assessment
  recommendations: jsonb("recommendations"),
  autoResolved: boolean("auto_resolved").default(false),
  createdAt: timestamp("created_at").defaultNow(),
});

// VPN Sessions and Usage
export const vpnSessions = pgTable("vpn_sessions", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").references(() => users.id),
  serverLocation: text("server_location").notNull(),
  connectionTime: timestamp("connection_time").defaultNow(),
  disconnectionTime: timestamp("disconnection_time"),
  dataTransferred: integer("data_transferred").default(0), // In MB
  realIp: text("real_ip"),
  vpnIp: text("vpn_ip"),
  protocol: text("protocol").default("OpenVPN"), // OpenVPN, WireGuard, IKEv2
});

// Password Manager Entries
export const passwordEntries = pgTable("password_entries", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").references(() => users.id),
  title: text("title").notNull(),
  website: text("website"),
  username: text("username"),
  encryptedPassword: text("encrypted_password").notNull(),
  notes: text("notes"),
  category: text("category").default("general"),
  isFavorite: boolean("is_favorite").default(false),
  lastUsed: timestamp("last_used"),
  passwordStrength: integer("password_strength"), // 0-100
  breachStatus: text("breach_status").default("safe"), // safe, compromised, unknown
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
});

// Schema validation
export const insertUserSchema = createInsertSchema(users).pick({
  email: true,
  username: true,
  password: true,
});

export const insertClipboardItemSchema = createInsertSchema(clipboardItems).pick({
  content: true,
  contentType: true,
  aiAnalysis: true,
  isEncrypted: true,
  isFavorite: true,
});

export const insertEncryptedFileSchema = createInsertSchema(encryptedFiles).pick({
  originalName: true,
  encryptedName: true,
  fileSize: true,
  encryptionAlgorithm: true,
  encryptionKey: true,
  filePath: true,
}).extend({
  isArVault: z.boolean().optional(),
  arUnlockCode: z.string().optional(),
});

export const insertContactSubmissionSchema = createInsertSchema(contactSubmissions).pick({
  name: true,
  email: true,
  inquiryType: true,
  message: true,
  priority: true,
});

export const insertPaymentSchema = createInsertSchema(payments).pick({
  stripePaymentIntentId: true,
  amount: true,
  currency: true,
  membershipTier: true,
  status: true,
  billingPeriod: true,
});

export const insertPasswordEntrySchema = createInsertSchema(passwordEntries).pick({
  title: true,
  website: true,
  username: true,
  encryptedPassword: true,
  notes: true,
  category: true,
  isFavorite: true,
});

export const insertSecurityAnalysisSchema = createInsertSchema(securityAnalysis).pick({
  analysisType: true,
  targetData: true,
  aiModel: true,
  findings: true,
  riskScore: true,
  recommendations: true,
});

// Types
export type User = typeof users.$inferSelect;
export type InsertUser = z.infer<typeof insertUserSchema>;
export type ClipboardItem = typeof clipboardItems.$inferSelect;
export type InsertClipboardItem = z.infer<typeof insertClipboardItemSchema>;
export type EncryptedFile = typeof encryptedFiles.$inferSelect;
export type InsertEncryptedFile = z.infer<typeof insertEncryptedFileSchema>;
export type DarkWebAlert = typeof darkWebAlerts.$inferSelect;
export type ContactSubmission = typeof contactSubmissions.$inferSelect;
export type InsertContactSubmission = z.infer<typeof insertContactSubmissionSchema>;
export type Payment = typeof payments.$inferSelect;
export type InsertPayment = z.infer<typeof insertPaymentSchema>;
export type PasswordEntry = typeof passwordEntries.$inferSelect;
export type InsertPasswordEntry = z.infer<typeof insertPasswordEntrySchema>;
export type SecurityAnalysis = typeof securityAnalysis.$inferSelect;
export type InsertSecurityAnalysis = z.infer<typeof insertSecurityAnalysisSchema>;
export type VpnSession = typeof vpnSessions.$inferSelect;
