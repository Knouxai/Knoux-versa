import { 
  users, clipboardItems, encryptedFiles, darkWebAlerts, contactSubmissions, 
  passwordEntries, securityAnalysis, vpnSessions, payments,
  type User, type InsertUser, type ClipboardItem, type InsertClipboardItem,
  type EncryptedFile, type InsertEncryptedFile, type DarkWebAlert,
  type ContactSubmission, type InsertContactSubmission, type PasswordEntry,
  type InsertPasswordEntry, type SecurityAnalysis, type InsertSecurityAnalysis,
  type VpnSession, type Payment, type InsertPayment
} from "@shared/schema";

export interface IStorage {
  getUser(id: number): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;
  
  // Clipboard management
  getClipboardItems(userId: number): Promise<ClipboardItem[]>;
  createClipboardItem(userId: number, item: InsertClipboardItem): Promise<ClipboardItem>;
  updateClipboardItem(id: number, updates: Partial<ClipboardItem>): Promise<ClipboardItem>;
  deleteClipboardItem(id: number): Promise<void>;
  
  // Contact submissions
  createContactSubmission(submission: InsertContactSubmission): Promise<ContactSubmission>;
  getContactSubmissions(): Promise<ContactSubmission[]>;
  
  // Encrypted files
  createEncryptedFile(userId: number, file: InsertEncryptedFile): Promise<EncryptedFile>;
  getEncryptedFiles(userId: number): Promise<EncryptedFile[]>;
  deleteEncryptedFile(id: number): Promise<void>;
  
  // Password manager
  createPasswordEntry(userId: number, entry: InsertPasswordEntry): Promise<PasswordEntry>;
  getPasswordEntries(userId: number): Promise<PasswordEntry[]>;
  updatePasswordEntry(id: number, updates: Partial<PasswordEntry>): Promise<PasswordEntry>;
  deletePasswordEntry(id: number): Promise<void>;
  
  // Dark web alerts
  getDarkWebAlerts(userId: number): Promise<DarkWebAlert[]>;
  createDarkWebAlert(userId: number, alert: Omit<DarkWebAlert, 'id' | 'userId' | 'createdAt'>): Promise<DarkWebAlert>;
  
  // Security analysis
  createSecurityAnalysis(userId: number, analysis: InsertSecurityAnalysis): Promise<SecurityAnalysis>;
  getSecurityAnalysis(userId: number): Promise<SecurityAnalysis[]>;
  
  // VPN sessions
  createVpnSession(userId: number, session: Omit<VpnSession, 'id' | 'userId'>): Promise<VpnSession>;
  getVpnSessions(userId: number): Promise<VpnSession[]>;
  
  // Payments
  createPayment(userId: number, payment: InsertPayment): Promise<Payment>;
  getPayments(userId: number): Promise<Payment[]>;
}

export class MemStorage implements IStorage {
  private users: Map<number, User>;
  private clipboardItems: Map<number, ClipboardItem>;
  private encryptedFiles: Map<number, EncryptedFile>;
  private contactSubmissions: Map<number, ContactSubmission>;
  private passwordEntries: Map<number, PasswordEntry>;
  private darkWebAlerts: Map<number, DarkWebAlert>;
  private securityAnalysis: Map<number, SecurityAnalysis>;
  private vpnSessions: Map<number, VpnSession>;
  private payments: Map<number, Payment>;
  currentId: number;

  constructor() {
    this.users = new Map();
    this.clipboardItems = new Map();
    this.encryptedFiles = new Map();
    this.contactSubmissions = new Map();
    this.passwordEntries = new Map();
    this.darkWebAlerts = new Map();
    this.securityAnalysis = new Map();
    this.vpnSessions = new Map();
    this.payments = new Map();
    this.currentId = 1;
  }

  async getUser(id: number): Promise<User | undefined> {
    return this.users.get(id);
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    for (const user of Array.from(this.users.values())) {
      if (user.username === username) {
        return user;
      }
    }
    return undefined;
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const id = this.currentId++;
    const user: User = { 
      ...insertUser, 
      id,
      membershipTier: "free",
      membershipExpiresAt: null,
      stripeCustomerId: null,
      subscriptionId: null,
      createdAt: new Date(),
      updatedAt: new Date()
    };
    this.users.set(id, user);
    return user;
  }

  // Clipboard management
  async getClipboardItems(userId: number): Promise<ClipboardItem[]> {
    const items = Array.from(this.clipboardItems.values()).filter(item => item.userId === userId);
    return items.sort((a, b) => (b.createdAt?.getTime() || 0) - (a.createdAt?.getTime() || 0));
  }

  async createClipboardItem(userId: number, item: InsertClipboardItem): Promise<ClipboardItem> {
    const id = this.currentId++;
    const clipboardItem: ClipboardItem = {
      id,
      userId,
      ...item,
      accessCount: 0,
      lastAccessed: null,
      createdAt: new Date()
    };
    this.clipboardItems.set(id, clipboardItem);
    return clipboardItem;
  }

  async updateClipboardItem(id: number, updates: Partial<ClipboardItem>): Promise<ClipboardItem> {
    const item = this.clipboardItems.get(id);
    if (!item) throw new Error("Clipboard item not found");
    
    const updatedItem = { ...item, ...updates };
    this.clipboardItems.set(id, updatedItem);
    return updatedItem;
  }

  async deleteClipboardItem(id: number): Promise<void> {
    this.clipboardItems.delete(id);
  }

  // Contact submissions
  async createContactSubmission(submission: InsertContactSubmission): Promise<ContactSubmission> {
    const id = this.currentId++;
    const contactSubmission: ContactSubmission = {
      id,
      ...submission,
      priority: submission.priority || "normal",
      isResolved: false,
      responseMessage: null,
      assignedTo: null,
      resolvedAt: null,
      createdAt: new Date()
    };
    this.contactSubmissions.set(id, contactSubmission);
    return contactSubmission;
  }

  async getContactSubmissions(): Promise<ContactSubmission[]> {
    return Array.from(this.contactSubmissions.values());
  }

  // Encrypted files
  async createEncryptedFile(userId: number, file: InsertEncryptedFile): Promise<EncryptedFile> {
    const id = this.currentId++;
    const encryptedFile: EncryptedFile = {
      id,
      userId,
      ...file,
      shareToken: null,
      expiresAt: null,
      createdAt: new Date()
    };
    this.encryptedFiles.set(id, encryptedFile);
    return encryptedFile;
  }

  async getEncryptedFiles(userId: number): Promise<EncryptedFile[]> {
    return Array.from(this.encryptedFiles.values()).filter(file => file.userId === userId);
  }

  async deleteEncryptedFile(id: number): Promise<void> {
    this.encryptedFiles.delete(id);
  }

  // Password manager
  async createPasswordEntry(userId: number, entry: InsertPasswordEntry): Promise<PasswordEntry> {
    const id = this.currentId++;
    const passwordEntry: PasswordEntry = {
      id,
      userId,
      ...entry,
      lastUsed: null,
      passwordStrength: 75, // Mock strength
      breachStatus: "safe",
      createdAt: new Date(),
      updatedAt: new Date()
    };
    this.passwordEntries.set(id, passwordEntry);
    return passwordEntry;
  }

  async getPasswordEntries(userId: number): Promise<PasswordEntry[]> {
    return Array.from(this.passwordEntries.values()).filter(entry => entry.userId === userId);
  }

  async updatePasswordEntry(id: number, updates: Partial<PasswordEntry>): Promise<PasswordEntry> {
    const entry = this.passwordEntries.get(id);
    if (!entry) throw new Error("Password entry not found");
    
    const updatedEntry = { ...entry, ...updates, updatedAt: new Date() };
    this.passwordEntries.set(id, updatedEntry);
    return updatedEntry;
  }

  async deletePasswordEntry(id: number): Promise<void> {
    this.passwordEntries.delete(id);
  }

  // Dark web alerts
  async getDarkWebAlerts(userId: number): Promise<DarkWebAlert[]> {
    return Array.from(this.darkWebAlerts.values()).filter(alert => alert.userId === userId);
  }

  async createDarkWebAlert(userId: number, alert: Omit<DarkWebAlert, 'id' | 'userId' | 'createdAt'>): Promise<DarkWebAlert> {
    const id = this.currentId++;
    const darkWebAlert: DarkWebAlert = {
      id,
      userId,
      ...alert,
      createdAt: new Date()
    };
    this.darkWebAlerts.set(id, darkWebAlert);
    return darkWebAlert;
  }

  // Security analysis
  async createSecurityAnalysis(userId: number, analysis: InsertSecurityAnalysis): Promise<SecurityAnalysis> {
    const id = this.currentId++;
    const securityAnalysisItem: SecurityAnalysis = {
      id,
      userId,
      ...analysis,
      autoResolved: false,
      createdAt: new Date()
    };
    this.securityAnalysis.set(id, securityAnalysisItem);
    return securityAnalysisItem;
  }

  async getSecurityAnalysis(userId: number): Promise<SecurityAnalysis[]> {
    return Array.from(this.securityAnalysis.values()).filter(analysis => analysis.userId === userId);
  }

  // VPN sessions
  async createVpnSession(userId: number, session: Omit<VpnSession, 'id' | 'userId'>): Promise<VpnSession> {
    const id = this.currentId++;
    const vpnSession: VpnSession = {
      id,
      userId,
      ...session
    };
    this.vpnSessions.set(id, vpnSession);
    return vpnSession;
  }

  async getVpnSessions(userId: number): Promise<VpnSession[]> {
    return Array.from(this.vpnSessions.values()).filter(session => session.userId === userId);
  }

  // Payments
  async createPayment(userId: number, payment: InsertPayment): Promise<Payment> {
    const id = this.currentId++;
    const paymentRecord: Payment = {
      id,
      userId,
      ...payment,
      createdAt: new Date()
    };
    this.payments.set(id, paymentRecord);
    return paymentRecord;
  }

  async getPayments(userId: number): Promise<Payment[]> {
    return Array.from(this.payments.values()).filter(payment => payment.userId === userId);
  }
}

export const storage = new MemStorage();