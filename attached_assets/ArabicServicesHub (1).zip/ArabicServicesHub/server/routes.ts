import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { insertContactSubmissionSchema, insertClipboardItemSchema, insertPasswordEntrySchema, insertEncryptedFileSchema } from "@shared/schema";
import { z } from "zod";
import crypto from "crypto";

// محاكاة معرف المستخدم للجلسة الحالية
const getCurrentUserId = (): number => 1;

// تحليل المحتوى بالذكاء الاصطناعي
const analyzeContent = (content: string, contentType: string) => {
  const analysis = {
    category: contentType,
    tags: [] as string[],
    sensitive: false,
    riskLevel: 'low' as 'low' | 'medium' | 'high',
    language: 'ar'
  };

  if (content.includes('password') || content.includes('كلمة مرور') || content.includes('سر')) {
    analysis.sensitive = true;
    analysis.riskLevel = 'high';
    analysis.tags.push('حساس');
  }

  if (content.match(/\b[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Z|a-z]{2,}\b/)) {
    analysis.tags.push('بريد إلكتروني');
  }

  if (content.match(/https?:\/\/[^\s]+/)) {
    analysis.tags.push('رابط');
  }

  if (content.match(/\+?[0-9]{10,}/)) {
    analysis.tags.push('رقم هاتف');
  }

  return analysis;
};

// تقييم قوة كلمة المرور
const calculatePasswordStrength = (password: string): number => {
  let score = 0;
  if (password.length >= 8) score += 25;
  if (password.length >= 12) score += 25;
  if (/[A-Z]/.test(password)) score += 15;
  if (/[a-z]/.test(password)) score += 15;
  if (/[0-9]/.test(password)) score += 10;
  if (/[^A-Za-z0-9]/.test(password)) score += 10;
  return Math.min(score, 100);
};

// تحليل أمني للبيانات
const performSecurityAnalysis = (targetData: string, analysisType: string) => {
  const findings = {
    vulnerabilities: [] as string[],
    threats: [] as string[],
    recommendations: [] as string[]
  };

  if (analysisType === 'password') {
    const strength = calculatePasswordStrength(targetData);
    if (strength < 70) {
      findings.vulnerabilities.push('كلمة مرور ضعيفة');
      findings.recommendations.push('استخدم كلمة مرور أقوى تحتوي على أحرف كبيرة وصغيرة وأرقام ورموز');
    }
  }

  if (analysisType === 'email' && targetData.includes('@')) {
    findings.threats.push('قد يكون البريد الإلكتروني عرضة للتصيد الاحتيالي');
    findings.recommendations.push('تحقق من مصدر الرسائل قبل النقر على الروابط');
  }

  return findings;
};

// حساب درجة المخاطر
const calculateRiskScore = (findings: any): number => {
  const vulnerabilityCount = findings.vulnerabilities?.length || 0;
  const threatCount = findings.threats?.length || 0;
  return Math.min((vulnerabilityCount * 30) + (threatCount * 20), 100);
};

// توليد التوصيات
const generateRecommendations = (findings: any) => {
  return findings.recommendations || ['لا توجد توصيات خاصة في الوقت الحالي'];
};

// توليد IP وهمي للـ VPN
const generateMockIp = (): string => {
  return `${Math.floor(Math.random() * 255)}.${Math.floor(Math.random() * 255)}.${Math.floor(Math.random() * 255)}.${Math.floor(Math.random() * 255)}`;
};

export async function registerRoutes(app: Express): Promise<Server> {
  // Contact form submission
  app.post("/api/contact", async (req, res) => {
    try {
      const validatedData = insertContactSubmissionSchema.parse(req.body);
      const submission = await storage.createContactSubmission(validatedData);
      res.json({ success: true, id: submission.id });
    } catch (error) {
      if (error instanceof z.ZodError) {
        res.status(400).json({ message: "Invalid form data", errors: error.errors });
      } else {
        console.error("Contact form error:", error);
        res.status(500).json({ message: "Failed to submit contact form" });
      }
    }
  });

  // ================== CLIPBOARD MANAGEMENT ==================

  app.get("/api/clipboard", async (req, res) => {
    try {
      const userId = getCurrentUserId();
      const items = await storage.getClipboardItems(userId);
      res.json(items);
    } catch (error) {
      console.error("Clipboard fetch error:", error);
      res.status(500).json({ message: "Failed to fetch clipboard items" });
    }
  });

  app.post("/api/clipboard", async (req, res) => {
    try {
      const userId = getCurrentUserId();
      const { content, contentType } = req.body;
      
      if (!content || typeof content !== 'string') {
        return res.status(400).json({ message: "Content is required" });
      }

      const analysis = analyzeContent(content, contentType || 'text');
      
      const newItem = {
        content: content.trim(),
        contentType: contentType || 'text',
        aiAnalysis: analysis,
        isEncrypted: analysis.sensitive,
        isFavorite: false
      };

      const validatedData = insertClipboardItemSchema.parse(newItem);
      const item = await storage.createClipboardItem(userId, validatedData);
      res.json(item);
    } catch (error) {
      if (error instanceof z.ZodError) {
        res.status(400).json({ message: "Invalid data", errors: error.errors });
      } else {
        console.error("Clipboard create error:", error);
        res.status(500).json({ message: "Failed to create clipboard item" });
      }
    }
  });

  app.patch("/api/clipboard/:id", async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const updates = req.body;
      
      const item = await storage.updateClipboardItem(id, updates);
      res.json(item);
    } catch (error) {
      console.error("Clipboard update error:", error);
      res.status(500).json({ message: "Failed to update clipboard item" });
    }
  });

  app.delete("/api/clipboard/:id", async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      await storage.deleteClipboardItem(id);
      res.json({ success: true });
    } catch (error) {
      console.error("Clipboard delete error:", error);
      res.status(500).json({ message: "Failed to delete clipboard item" });
    }
  });

  // ================== PASSWORD MANAGER ==================

  app.get("/api/passwords", async (req, res) => {
    try {
      const userId = getCurrentUserId();
      const passwords = await storage.getPasswordEntries(userId);
      res.json(passwords);
    } catch (error) {
      console.error("Password fetch error:", error);
      res.status(500).json({ message: "Failed to fetch passwords" });
    }
  });

  app.post("/api/passwords", async (req, res) => {
    try {
      const userId = getCurrentUserId();
      const { title, username, password, website, notes } = req.body;
      
      if (!title || !password) {
        return res.status(400).json({ message: "Title and password are required" });
      }

      const encryptedPassword = crypto.createHash('sha256').update(password).digest('hex');
      const passwordStrength = calculatePasswordStrength(password);
      
      const newPassword = {
        title,
        username: username || null,
        encryptedPassword,
        website: website || null,
        notes: notes || null,
        passwordStrength,
        breachStatus: 'safe',
        isFavorite: false
      };

      const validatedData = insertPasswordEntrySchema.parse(newPassword);
      const passwordEntry = await storage.createPasswordEntry(userId, validatedData);
      res.json(passwordEntry);
    } catch (error) {
      if (error instanceof z.ZodError) {
        res.status(400).json({ message: "Invalid data", errors: error.errors });
      } else {
        console.error("Password create error:", error);
        res.status(500).json({ message: "Failed to create password entry" });
      }
    }
  });

  app.patch("/api/passwords/:id", async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const updates = req.body;
      
      if (updates.password) {
        updates.encryptedPassword = crypto.createHash('sha256').update(updates.password).digest('hex');
        updates.passwordStrength = calculatePasswordStrength(updates.password);
        delete updates.password;
      }
      
      const passwordEntry = await storage.updatePasswordEntry(id, updates);
      res.json(passwordEntry);
    } catch (error) {
      console.error("Password update error:", error);
      res.status(500).json({ message: "Failed to update password entry" });
    }
  });

  app.delete("/api/passwords/:id", async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      await storage.deletePasswordEntry(id);
      res.json({ success: true });
    } catch (error) {
      console.error("Password delete error:", error);
      res.status(500).json({ message: "Failed to delete password entry" });
    }
  });

  // ================== FILE ENCRYPTION ==================

  app.get("/api/files", async (req, res) => {
    try {
      const userId = getCurrentUserId();
      const files = await storage.getEncryptedFiles(userId);
      res.json(files);
    } catch (error) {
      console.error("Files fetch error:", error);
      res.status(500).json({ message: "Failed to fetch files" });
    }
  });

  app.post("/api/files", async (req, res) => {
    try {
      const userId = getCurrentUserId();
      const { originalName, fileSize, encryptionAlgorithm } = req.body;
      
      if (!originalName || !fileSize) {
        return res.status(400).json({ message: "File name and size are required" });
      }

      const encryptedName = crypto.randomBytes(16).toString('hex') + '.knx';
      const encryptionKey = crypto.randomBytes(32).toString('hex');
      const filePath = `/encrypted/${encryptedName}`;
      
      const newFile = {
        originalName,
        encryptedName,
        fileSize: parseInt(fileSize),
        encryptionAlgorithm: encryptionAlgorithm || 'AES-256-GCM',
        encryptionKey,
        filePath,
        isArVault: false,
        arUnlockCode: null,
        shareToken: null,
        expiresAt: null
      };

      const validatedData = insertEncryptedFileSchema.parse(newFile);
      const file = await storage.createEncryptedFile(userId, validatedData);
      res.json(file);
    } catch (error) {
      if (error instanceof z.ZodError) {
        res.status(400).json({ message: "Invalid data", errors: error.errors });
      } else {
        console.error("File create error:", error);
        res.status(500).json({ message: "Failed to create file entry" });
      }
    }
  });

  app.delete("/api/files/:id", async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      await storage.deleteEncryptedFile(id);
      res.json({ success: true });
    } catch (error) {
      console.error("File delete error:", error);
      res.status(500).json({ message: "Failed to delete file" });
    }
  });

  // ================== SECURITY ANALYSIS ==================

  app.get("/api/security-analysis", async (req, res) => {
    try {
      const userId = getCurrentUserId();
      const analyses = await storage.getSecurityAnalysis(userId);
      res.json(analyses);
    } catch (error) {
      console.error("Security analysis fetch error:", error);
      res.status(500).json({ message: "Failed to fetch security analysis" });
    }
  });

  app.post("/api/security-analysis", async (req, res) => {
    try {
      const userId = getCurrentUserId();
      const { analysisType, targetData } = req.body;
      
      if (!analysisType || !targetData) {
        return res.status(400).json({ message: "Analysis type and target data are required" });
      }

      const findings = performSecurityAnalysis(targetData, analysisType);
      const riskScore = calculateRiskScore(findings);
      const recommendations = generateRecommendations(findings);
      
      const newAnalysis = {
        analysisType,
        targetData,
        aiModel: 'KNOUX-Security-AI-v1.0',
        findings,
        riskScore,
        recommendations,
        autoResolved: false
      };

      const analysis = await storage.createSecurityAnalysis(userId, newAnalysis);
      res.json(analysis);
    } catch (error) {
      console.error("Security analysis create error:", error);
      res.status(500).json({ message: "Failed to create security analysis" });
    }
  });

  // ================== VPN SESSIONS ==================

  app.get("/api/vpn-sessions", async (req, res) => {
    try {
      const userId = getCurrentUserId();
      const sessions = await storage.getVpnSessions(userId);
      res.json(sessions);
    } catch (error) {
      console.error("VPN sessions fetch error:", error);
      res.status(500).json({ message: "Failed to fetch VPN sessions" });
    }
  });

  app.post("/api/vpn-sessions", async (req, res) => {
    try {
      const userId = getCurrentUserId();
      const { serverLocation, protocol } = req.body;
      
      const session = {
        serverLocation: serverLocation || 'Germany-Frankfurt',
        serverIp: generateMockIp(),
        protocol: protocol || 'WireGuard',
        connectedAt: new Date(),
        disconnectedAt: null,
        dataTransferred: '0 MB',
        status: 'connected'
      };

      const vpnSession = await storage.createVpnSession(userId, session);
      res.json(vpnSession);
    } catch (error) {
      console.error("VPN session create error:", error);
      res.status(500).json({ message: "Failed to create VPN session" });
    }
  });

  // ================== DARK WEB ALERTS ==================

  app.get("/api/dark-web-alerts", async (req, res) => {
    try {
      const userId = getCurrentUserId();
      const alerts = await storage.getDarkWebAlerts(userId);
      res.json(alerts);
    } catch (error) {
      console.error("Dark web alerts fetch error:", error);
      res.status(500).json({ message: "Failed to fetch dark web alerts" });
    }
  });

  app.post("/api/dark-web-alerts", async (req, res) => {
    try {
      const userId = getCurrentUserId();
      const { alertType, targetData, riskLevel } = req.body;
      
      const alert = {
        alertType: alertType || 'email_breach',
        targetData: targetData || 'example@email.com',
        riskLevel: riskLevel || 'medium',
        status: 'active',
        details: 'تم العثور على بيانات مطابقة في قاعدة بيانات مخترقة',
        resolvedAt: null,
        createdAt: new Date()
      };

      const darkWebAlert = await storage.createDarkWebAlert(userId, alert);
      res.json(darkWebAlert);
    } catch (error) {
      console.error("Dark web alert create error:", error);
      res.status(500).json({ message: "Failed to create dark web alert" });
    }
  });

  // ================== PAYMENTS ==================

  app.get("/api/payments", async (req, res) => {
    try {
      const userId = getCurrentUserId();
      const payments = await storage.getPayments(userId);
      res.json(payments);
    } catch (error) {
      console.error("Payments fetch error:", error);
      res.status(500).json({ message: "Failed to fetch payments" });
    }
  });

  app.post("/api/payments", async (req, res) => {
    try {
      const userId = getCurrentUserId();
      const { amount, membershipTier, billingPeriod } = req.body;
      
      const payment = {
        amount: amount || '49.00',
        currency: 'USD',
        status: 'completed',
        membershipTier: membershipTier || 'professional',
        billingPeriod: billingPeriod || 'monthly',
        stripePaymentIntentId: `pi_${crypto.randomBytes(16).toString('hex')}`
      };

      const paymentRecord = await storage.createPayment(userId, payment);
      res.json(paymentRecord);
    } catch (error) {
      console.error("Payment create error:", error);
      res.status(500).json({ message: "Failed to create payment" });
    }
  });

  const httpServer = createServer(app);
  return httpServer;
}