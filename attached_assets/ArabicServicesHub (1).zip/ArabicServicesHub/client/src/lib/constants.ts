// خدمات KNOUX الحقيقية والشاملة
export const SERVICES = [
  {
    id: 'ai-clipboard',
    title: 'مدير الحافظة الذكي',
    subtitle: 'تقنية الذكاء الاصطناعي المتقدمة',
    description: 'إدارة متطورة للحافظة مع تحليل ذكي للمحتوى وتصنيف آلي وبحث سيمانتيك فائق السرعة',
    icon: 'brain',
    color: 'from-[hsl(var(--electric-blue))] via-cyan-400 to-blue-500',
    status: 'نشط ومتعلم',
    statusColor: 'text-emerald-400',
    features: ['تحليل المحتوى بالذكاء الاصطناعي', 'مزامنة فورية', 'تشفير من الطرف للطرف', 'بحث ذكي متقدم']
  },
  {
    id: 'quantum-encryption',
    title: 'التشفير الكمي المتقدم',
    subtitle: 'حماية مضادة للحاسوب الكمي',
    description: 'تشفير من الجيل القادم بخوارزميات AES-512 و ChaCha20-Poly1305 المقاومة للحاسوب الكمي',
    icon: 'atom',
    color: 'from-[hsl(var(--deep-purple))] via-violet-500 to-purple-600',
    status: 'محمي كمياً',
    statusColor: 'text-violet-400',
    features: ['تشفير AES-512', 'خوارزميات مقاومة كمياً', 'مفاتيح متجددة', 'تشفير هجين متعدد الطبقات']
  },
  {
    id: 'biometric-vault',
    title: 'خزنة البيانات البيومترية',
    subtitle: 'مصادقة متعددة العوامل',
    description: 'حماية متقدمة بالبصمة وبصمة العين والتعرف على الوجه مع تقنية الواقع المعزز',
    icon: 'fingerprint',
    color: 'from-[hsl(var(--neon-pink))] via-rose-500 to-pink-600',
    status: 'محمي بيومترياً',
    statusColor: 'text-rose-400',
    features: ['بصمة الإصبع', 'مسح شبكية العين', 'التعرف على الوجه', 'خزنة الواقع المعزز']
  },
  {
    id: 'neural-vpn',
    title: 'شبكة VPN العصبية',
    subtitle: 'توجيه ذكي مدعوم بالذكاء الاصطناعي',
    description: 'شبكة VPN ذكية مع 500+ خادم عالمي وتوجيه آلي للأداء الأمثل وحماية DDoS',
    icon: 'network-wired',
    color: 'from-emerald-500 via-green-500 to-teal-600',
    status: 'متصل عالمياً',
    statusColor: 'text-emerald-400',
    features: ['500+ خادم عالمي', 'توجيه ذكي', 'حماية DDoS', 'بروتوكولات متعددة']
  },
  {
    id: 'quantum-chat',
    title: 'المحادثات الكمية الآمنة',
    subtitle: 'تشفير كمي للرسائل',
    description: 'نظام محادثات مع تشفير كمي متقدم ورسائل ذاتية التدمير وحماية كاملة للخصوصية',
    icon: 'comments-dollar',
    color: 'from-orange-500 via-amber-500 to-yellow-500',
    status: 'آمن كمياً',
    statusColor: 'text-amber-400',
    features: ['تشفير كمي', 'رسائل ذاتية التدمير', 'مكالمات مشفرة', 'مجموعات آمنة']
  },
  {
    id: 'darkweb-sentinel',
    title: 'حارس الشبكة المظلمة',
    subtitle: 'مراقبة متقدمة 24/7',
    description: 'مراقبة ذكية للشبكة المظلمة مع كشف التسريبات وتحليل التهديدات وإنذارات فورية',
    icon: 'user-secret',
    color: 'from-red-500 via-pink-500 to-rose-600',
    status: 'يراقب الآن',
    statusColor: 'text-red-400',
    features: ['مراقبة 24/7', 'كشف التسريبات', 'تحليل التهديدات', 'إنذارات فورية']
  },
  {
    id: 'quantum-cloud',
    title: 'السحابة الكمية الآمنة',
    subtitle: 'تخزين سحابي بتشفير كمي',
    description: 'تخزين سحابي مع تشفير كمي متقدم ومزامنة فورية وحماية شاملة للملفات',
    icon: 'cloud-upload-alt',
    color: 'from-indigo-500 via-blue-500 to-cyan-600',
    status: 'مزامن كمياً',
    statusColor: 'text-blue-400',
    features: ['تشفير كمي للملفات', 'مزامنة فورية', 'نسخ احتياطية آلية', 'مشاركة آمنة']
  },
  {
    id: 'ai-guardian',
    title: 'الحارس الذكي المتقدم',
    subtitle: 'ذكاء اصطناعي دفاعي',
    description: 'نظام حماية ذكي يستخدم تعلم الآلة لكشف التهديدات والاستجابة التلقائية للهجمات',
    icon: 'shield-virus',
    color: 'from-teal-500 via-cyan-500 to-blue-600',
    status: 'يحمي بذكاء',
    statusColor: 'text-teal-400',
    features: ['كشف التهديدات بالذكاء الاصطناعي', 'استجابة آلية', 'تعلم السلوك', 'حماية استباقية']
  },
  {
    id: 'crypto-wallet',
    title: 'محفظة العملات المشفرة',
    subtitle: 'أمان متعدد التوقيعات',
    description: 'محفظة آمنة للعملات المشفرة مع دعم متعدد التوقيعات وتخزين بارد وتداول آمن',
    icon: 'coins',
    color: 'from-[hsl(var(--premium-gold))] via-yellow-500 to-orange-500',
    status: 'محمي رقمياً',
    statusColor: 'text-yellow-400',
    features: ['دعم متعدد العملات', 'تخزين بارد', 'تداول آمن', 'نسخ احتياطية مشفرة']
  },
  {
    id: 'secure-browser',
    title: 'متصفح الأمان المتقدم',
    subtitle: 'تصفح مجهول بالكامل',
    description: 'متصفح آمن مع حماية شاملة من التتبع وحجب الإعلانات وتشفير DNS المتقدم',
    icon: 'globe-americas',
    color: 'from-purple-500 via-violet-500 to-indigo-600',
    status: 'آمن ومجهول',
    statusColor: 'text-purple-400',
    features: ['تصفح مجهول', 'حجب التتبع', 'تشفير DNS', 'حماية من البرمجيات الخبيثة']
  },
  {
    id: 'identity-shield',
    title: 'درع الهوية الرقمية',
    subtitle: 'حماية شاملة للهوية',
    description: 'حماية متقدمة للهوية الرقمية مع كشف سرقة الهوية ومراقبة الائتمان والحماية القانونية',
    icon: 'id-card',
    color: 'from-green-500 via-emerald-500 to-teal-600',
    status: 'محمي بالكامل',
    statusColor: 'text-green-400',
    features: ['مراقبة الائتمان', 'كشف سرقة الهوية', 'حماية قانونية', 'تأمين الهوية']
  },
  {
    id: 'steganography',
    title: 'إخفاء البيانات المتقدم',
    subtitle: 'تقنية الإخفاء الرقمي',
    description: 'تقنيات متقدمة لإخفاء البيانات داخل الصور والملفات مع تشفير غير مرئي',
    icon: 'eye-slash',
    color: 'from-gray-500 via-slate-500 to-zinc-600',
    status: 'مخفي تماماً',
    statusColor: 'text-gray-400',
    features: ['إخفاء في الصور', 'تشفير غير مرئي', 'بيانات متعددة الطبقات', 'استخراج آمن']
  }
];

export const QUICK_ACTIONS = [
  {
    id: 'ai-scan',
    title: 'فحص ذكي شامل',
    description: 'فحص كامل للنظام بالذكاء الاصطناعي',
    icon: 'brain',
    color: 'text-[hsl(var(--electric-blue))]',
    gradient: 'from-[hsl(var(--electric-blue))] to-cyan-500'
  },
  {
    id: 'quantum-encrypt',
    title: 'تشفير كمي فوري',
    description: 'تشفير الملفات المحددة بتقنية كمية',
    icon: 'atom',
    color: 'text-[hsl(var(--deep-purple))]',
    gradient: 'from-[hsl(var(--deep-purple))] to-violet-500'
  },
  {
    id: 'stealth-mode',
    title: 'وضع التخفي المتقدم',
    description: 'تفعيل الحماية المتقدمة والتخفي',
    icon: 'user-secret',
    color: 'text-[hsl(var(--neon-pink))]',
    gradient: 'from-[hsl(var(--neon-pink))] to-rose-500'
  },
  {
    id: 'emergency-lock',
    title: 'القفل الطارئ',
    description: 'إغلاق فوري لجميع البيانات الحساسة',
    icon: 'exclamation-triangle',
    color: 'text-red-400',
    gradient: 'from-red-500 to-orange-500'
  },
  {
    id: 'secure-backup',
    title: 'نسخ احتياطي مشفر',
    description: 'نسخ احتياطي آمن لجميع البيانات',
    icon: 'shield-alt',
    color: 'text-emerald-400',
    gradient: 'from-emerald-500 to-green-500'
  },
  {
    id: 'dark-scan',
    title: 'فحص الشبكة المظلمة',
    description: 'بحث فوري عن تسريبات البيانات',
    icon: 'search',
    color: 'text-amber-400',
    gradient: 'from-amber-500 to-yellow-500'
  }
];

export const MEMBERSHIP_TIERS = [
  {
    id: 'essential',
    name: 'الأساسي',
    nameEn: 'Essential',
    price: 19,
    period: 'شهر',
    description: 'مثالي للاستخدام الشخصي والحماية الأساسية',
    icon: 'shield',
    color: 'from-slate-400 via-gray-500 to-zinc-600',
    features: [
      'تشفير AES-256 المتقدم',
      'مدير كلمات المرور (500 إدخال)',
      'تاريخ الحافظة (7 أيام)',
      'مصادقة متعددة العوامل',
      'دعم عبر البريد الإلكتروني',
      'حماية أساسية من البرمجيات الخبيثة',
      'VPN أساسي (10 خوادم)'
    ],
    buttonText: 'ابدأ الآن',
    buttonClass: 'glass-morphism border-gray-400/30 hover:border-gray-400/60 hover-glow'
  },
  {
    id: 'professional',
    name: 'الاحترافي',
    nameEn: 'Professional',
    price: 49,
    period: 'شهر',
    description: 'حماية متقدمة للمحترفين ورجال الأعمال',
    icon: 'rocket',
    color: 'from-[hsl(var(--electric-blue))] via-cyan-500 to-[hsl(var(--deep-purple))]',
    popular: true,
    features: [
      'تشفير كمي AES-512 + ChaCha20',
      'مدير كلمات مرور غير محدود',
      'مدير الحافظة الذكي بالذكاء الاصطناعي',
      'تخزين سحابي مشفر (500GB)',
      'مراقبة الشبكة المظلمة 24/7',
      'VPN عالمي (200+ خادم)',
      'دعم أولوية عبر الدردشة المباشرة',
      'حماية متقدمة من التصيد',
      'تحليل أمني بالذكاء الاصطناعي'
    ],
    buttonText: 'ترقية للاحترافي',
    buttonClass: 'bg-gradient-to-r from-[hsl(var(--electric-blue))] via-cyan-500 to-[hsl(var(--deep-purple))] animate-glow hover-glow'
  },
  {
    id: 'golden',
    name: 'النخبة الذهبية',
    nameEn: 'Golden Elite',
    price: 149,
    period: 'شهر',
    description: 'الحماية المطلقة للشركات والأفراد المميزين',
    icon: 'crown',
    color: 'from-[hsl(var(--premium-gold))] via-yellow-400 to-orange-500',
    premium: true,
    features: [
      'تشفير كمي عسكري متعدد الطبقات',
      'جميع الخدمات بلا حدود',
      'مساعد أمني ذكي شخصي',
      'تخزين سحابي كمي غير محدود',
      'مراقبة تهديدات 24/7 مع فريق خبراء',
      'شبكة VPN عالمية (500+ خادم)',
      'خبير أمان شخصي مخصص',
      'حلول أمان مخصصة حسب الطلب',
      'حماية قانونية وتأمين ضد التسريبات',
      'استجابة طوارئ فورية',
      'تقارير أمنية مفصلة شهرياً',
      'وصول مبكر لجميع الميزات الجديدة'
    ],
    buttonText: 'انضم للنخبة الذهبية',
    buttonClass: 'bg-gradient-to-r from-[hsl(var(--premium-gold))] via-yellow-400 to-orange-500 animate-glow hover-glow premium-shadow'
  }
];

export const GOLDEN_BENEFITS = [
  {
    title: 'المعالجة الفورية المتقدمة',
    description: 'تشفير ومعالجة بسرعة البرق مع موارد مخصصة حصرياً للعضو الذهبي',
    icon: 'bolt',
    color: 'from-[hsl(var(--premium-gold))] to-yellow-500'
  },
  {
    title: 'مستشار أمان شخصي',
    description: 'خبير أمن سيبراني مخصص لك شخصياً للاستشارات والحماية المتقدمة',
    icon: 'user-tie',
    color: 'from-blue-500 to-cyan-500'
  },
  {
    title: 'حلول مخصصة حسب الطلب',
    description: 'تطوير حلول أمان مخصصة ومصممة خصيصاً لاحتياجاتك الفريدة',
    icon: 'magic',
    color: 'from-purple-500 to-pink-500'
  },
  {
    title: 'وصول عالمي مميز',
    description: 'شبكة خوادم عالمية حصرية مع أولوية النطاق الترددي والأداء الفائق',
    icon: 'globe-americas',
    color: 'from-green-500 to-emerald-500'
  },
  {
    title: 'مكانة VIP حصرية',
    description: 'وصول حصري للميزات التجريبية والفعاليات المميزة والمحتوى الخاص',
    icon: 'gem',
    color: 'from-rose-500 to-pink-500'
  },
  {
    title: 'دعم VIP على مدار الساعة',
    description: 'دعم فوري عبر قنوات متعددة مع أولوية مطلقة وخط ساخن مباشر',
    icon: 'headset',
    color: 'from-orange-500 to-red-500'
  },
  {
    title: 'حماية قانونية شاملة',
    description: 'تأمين قانوني ضد سرقة الهوية والتسريبات مع فريق قانوني متخصص',
    icon: 'balance-scale',
    color: 'from-indigo-500 to-blue-500'
  },
  {
    title: 'تحليلات أمنية متقدمة',
    description: 'تقارير أمنية مفصلة وتحليلات ذكية لحالة الأمان الشخصي',
    icon: 'chart-line',
    color: 'from-teal-500 to-cyan-500'
  }
];

export const CLIPBOARD_DEMO_ITEMS = [
  {
    id: 1,
    type: 'رابط آمن',
    content: 'https://secure.knoux.com/quantum-encryption-api',
    icon: 'link',
    color: 'from-[hsl(var(--electric-blue))] to-cyan-500',
    time: 'منذ دقيقتين',
    tags: ['تطوير', 'تشفير كمي', 'API'],
    aiAnalysis: {
      security: 'آمن - مُشفر بـ HTTPS',
      category: 'رابط تطوير',
      sensitivity: 'منخفضة'
    }
  },
  {
    id: 2,
    type: 'نص مشفر',
    content: 'اجتماع مهم غداً الساعة 3 عصراً لمناقشة بروتوكول الأمان الجديد مع فريق KNOUX...',
    icon: 'file-text',
    color: 'from-[hsl(var(--deep-purple))] to-violet-500',
    time: 'منذ 5 دقائق',
    tags: ['اجتماع', 'عمل', 'سري'],
    aiAnalysis: {
      security: 'حساس - مُشفر تلقائياً',
      category: 'معلومات عمل',
      sensitivity: 'متوسطة'
    }
  },
  {
    id: 3,
    type: 'كود مصدري',
    content: 'const quantumEncrypt = async (data) => {\n  return await KNOUX.encrypt(data, "AES-512-GCM");\n}',
    icon: 'code',
    color: 'from-emerald-500 to-green-500',
    time: 'منذ 15 دقيقة',
    tags: ['JavaScript', 'تشفير', 'كود'],
    aiAnalysis: {
      security: 'آمن - كود تشفير',
      category: 'برمجة',
      sensitivity: 'منخفضة'
    }
  },
  {
    id: 4,
    type: 'كلمة مرور',
    content: '●●●●●●●●●●●●●●●●',
    icon: 'key',
    color: 'from-[hsl(var(--neon-pink))] to-rose-500',
    time: 'منذ ساعة',
    tags: ['بيانات اعتماد', 'مُؤمن تلقائياً', 'حساس'],
    aiAnalysis: {
      security: 'سري للغاية - مُشفر بتقنية كمية',
      category: 'بيانات اعتماد',
      sensitivity: 'عالية جداً'
    }
  },
  {
    id: 5,
    type: 'ملف مشفر',
    content: 'تقرير_الأمان_السنوي_2024.pdf.knx',
    icon: 'file-shield',
    color: 'from-[hsl(var(--premium-gold))] to-yellow-500',
    time: 'منذ ساعتين',
    tags: ['مستند', 'تقرير', 'مشفر'],
    aiAnalysis: {
      security: 'مُشفر كمياً - حماية عسكرية',
      category: 'مستند سري',
      sensitivity: 'سري للغاية'
    }
  },
  {
    id: 6,
    type: 'عملة مشفرة',
    content: 'bc1qxy2kgdygjrsqtzq2n0yrf2493p83kkfjhx0wlh',
    icon: 'bitcoin-sign',
    color: 'from-orange-500 to-amber-500',
    time: 'منذ 3 ساعات',
    tags: ['محفظة', 'بيتكوين', 'مالي'],
    aiAnalysis: {
      security: 'محمي بـ Multi-Sig',
      category: 'عملة رقمية',
      sensitivity: 'عالية'
    }
  }
];

export const STATS = [
  { 
    value: '5.7M+', 
    label: 'مستخدم نشط', 
    labelEn: 'Active Users',
    color: 'text-[hsl(var(--electric-blue))]',
    icon: 'users',
    description: 'يثق بنا ملايين المستخدمين حول العالم'
  },
  { 
    value: '99.99%', 
    label: 'وقت التشغيل', 
    labelEn: 'Uptime',
    color: 'text-[hsl(var(--neon-green))]',
    icon: 'heartbeat',
    description: 'خدمة متاحة على مدار الساعة بدون انقطاع'
  },
  { 
    value: '2.8PB', 
    label: 'بيانات محمية', 
    labelEn: 'Data Protected',
    color: 'text-[hsl(var(--premium-gold))]',
    icon: 'shield-alt',
    description: 'بيتابايت من البيانات المشفرة والمحمية'
  },
  { 
    value: '195+', 
    label: 'دولة', 
    labelEn: 'Countries',
    color: 'text-[hsl(var(--deep-purple))]',
    icon: 'globe-americas',
    description: 'خدمة عالمية في جميع أنحاء العالم'
  },
  { 
    value: '0', 
    label: 'انتهاكات أمنية', 
    labelEn: 'Security Breaches',
    color: 'text-emerald-400',
    icon: 'lock',
    description: 'لم يحدث أي اختراق أمني منذ التأسيس'
  },
  { 
    value: '47ms', 
    label: 'زمن التشفير', 
    labelEn: 'Encryption Speed',
    color: 'text-[hsl(var(--neon-pink))]',
    icon: 'bolt',
    description: 'متوسط سرعة التشفير الكمي للملفات'
  }
];
