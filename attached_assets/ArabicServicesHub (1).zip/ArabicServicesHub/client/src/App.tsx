import { Switch, Route, useLocation } from "wouter";
import { queryClient } from "./lib/queryClient";
import { QueryClientProvider } from "@tanstack/react-query";
import { Toaster } from "@/components/ui/toaster";
import { TooltipProvider } from "@/components/ui/tooltip";
import { Navigation } from "@/components/Navigation";
import { Hero } from "@/components/Hero";
import { ServiceGrid } from "@/components/ServiceGrid";
import { ClipboardDemo } from "@/components/ClipboardDemo";
import { GoldenMembership } from "@/components/GoldenMembership";
import { ContactSection } from "@/components/ContactSection";
import Dashboard from "@/pages/Dashboard";
import Membership from "@/pages/Membership";
import ClipboardManager from "@/pages/ClipboardManager";
import PasswordManager from "@/pages/PasswordManager";
import NotFound from "@/pages/not-found";

function HomePage() {
  return (
    <div className="min-h-screen bg-background text-foreground">
      <Navigation />
      <Hero />
      <div id="services">
        <ServiceGrid />
      </div>
      <div id="clipboard">
        <ClipboardDemo />
      </div>
      <div id="membership">
        <GoldenMembership />
      </div>
      <div id="contact">
        <ContactSection />
      </div>
    </div>
  );
}

function Router() {
  const [location] = useLocation();
  
  if (location === "/" || location === "") {
    return <HomePage />;
  }
  
  return (
    <div className="min-h-screen bg-background text-foreground">
      <Navigation />
      <Switch>
        <Route path="/dashboard" component={Dashboard} />
        <Route path="/membership" component={Membership} />
        <Route path="/clipboard" component={ClipboardManager} />
        <Route path="/passwords" component={PasswordManager} />
        <Route component={NotFound} />
      </Switch>
    </div>
  );
}

function App() {
  return (
    <QueryClientProvider client={queryClient}>
      <TooltipProvider>
        <div className="dark">
          <Toaster />
          <Router />
        </div>
      </TooltipProvider>
    </QueryClientProvider>
  );
}

export default App;
