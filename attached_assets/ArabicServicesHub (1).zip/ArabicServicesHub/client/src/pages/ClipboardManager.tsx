import { useState, useEffect } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Badge } from "@/components/ui/badge";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";
import { ClipboardItem } from "@shared/schema";
import { formatDistanceToNow } from "date-fns";
import { ar } from "date-fns/locale";

export default function ClipboardManager() {
  const [selectedItem, setSelectedItem] = useState<ClipboardItem | null>(null);
  const [newContent, setNewContent] = useState("");
  const [contentType, setContentType] = useState("text");
  const [searchTerm, setSearchTerm] = useState("");
  const queryClient = useQueryClient();

  // جلب عناصر الحافظة
  const { data: clipboardItems = [], isLoading } = useQuery({
    queryKey: ['/api/clipboard'],
    queryFn: () => apiRequest<ClipboardItem[]>('/api/clipboard'),
  });

  // إضافة عنصر جديد
  const addItemMutation = useMutation({
    mutationFn: (data: { content: string; contentType: string }) => 
      apiRequest('/api/clipboard', { method: 'POST', body: JSON.stringify(data) }),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/clipboard'] });
      setNewContent("");
    },
  });

  // حذف عنصر
  const deleteItemMutation = useMutation({
    mutationFn: (id: number) => 
      apiRequest(`/api/clipboard/${id}`, { method: 'DELETE' }),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/clipboard'] });
      setSelectedItem(null);
    },
  });

  // تحديث عنصر كمفضل
  const toggleFavoriteMutation = useMutation({
    mutationFn: ({ id, isFavorite }: { id: number; isFavorite: boolean }) => 
      apiRequest(`/api/clipboard/${id}`, { 
        method: 'PATCH', 
        body: JSON.stringify({ isFavorite: !isFavorite }) 
      }),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/clipboard'] });
    },
  });

  // نسخ إلى الحافظة
  const copyToClipboard = async (content: string) => {
    try {
      await navigator.clipboard.writeText(content);
      // يمكن إضافة toast notification هنا
    } catch (error) {
      console.error('فشل في النسخ:', error);
    }
  };

  // تصفية العناصر
  const filteredItems = clipboardItems.filter(item =>
    item.content.toLowerCase().includes(searchTerm.toLowerCase()) ||
    item.contentType.toLowerCase().includes(searchTerm.toLowerCase())
  );

  // تحديد نوع المحتوى تلقائياً
  const detectContentType = (content: string): string => {
    if (content.match(/^https?:\/\//)) return "url";
    if (content.match(/^\w+@\w+\.\w+/)) return "email";
    if (content.match(/^\+?\d+[-\s\d]+$/)) return "phone";
    if (content.includes("function") || content.includes("const") || content.includes("=>")) return "code";
    if (content.match(/^\d{4}-\d{2}-\d{2}/)) return "date";
    return "text";
  };

  const handleAddItem = () => {
    if (!newContent.trim()) return;
    
    const detectedType = contentType === "auto" ? detectContentType(newContent) : contentType;
    addItemMutation.mutate({
      content: newContent.trim(),
      contentType: detectedType
    });
  };

  const getContentIcon = (type: string) => {
    const icons: Record<string, string> = {
      text: "fas fa-font",
      url: "fas fa-link",
      email: "fas fa-envelope",
      phone: "fas fa-phone",
      code: "fas fa-code",
      date: "fas fa-calendar",
      password: "fas fa-key",
      file: "fas fa-file"
    };
    return icons[type] || "fas fa-font";
  };

  const getContentColor = (type: string) => {
    const colors: Record<string, string> = {
      text: "text-gray-400",
      url: "text-[hsl(var(--electric-blue))]",
      email: "text-[hsl(var(--neon-green))]",
      phone: "text-[hsl(var(--deep-purple))]",
      code: "text-emerald-400",
      date: "text-orange-400",
      password: "text-[hsl(var(--neon-pink))]",
      file: "text-[hsl(var(--premium-gold))]"
    };
    return colors[type] || "text-gray-400";
  };

  if (isLoading) {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center">
        <div className="glass-morphism rounded-2xl p-8">
          <div className="animate-spin w-8 h-8 border-2 border-[hsl(var(--electric-blue))] border-t-transparent rounded-full mx-auto"></div>
          <p className="text-center mt-4 text-gray-300">جاري تحميل الحافظة الذكية...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-background pt-24 pb-12">
      <div className="max-w-7xl mx-auto px-6">
        {/* رأس الصفحة */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="text-center mb-12"
        >
          <h1 className="text-5xl font-black text-gradient mb-4">الحافظة الذكية</h1>
          <p className="text-xl text-gray-300 max-w-2xl mx-auto">
            مدير الحافظة المتقدم مع الذكاء الاصطناعي وتحليل المحتوى التلقائي
          </p>
        </motion.div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          {/* قائمة العناصر */}
          <div className="lg:col-span-2">
            {/* شريط البحث والإضافة */}
            <motion.div
              initial={{ opacity: 0, x: -20 }}
              animate={{ opacity: 1, x: 0 }}
              className="glass-morphism rounded-2xl p-6 mb-6"
            >
              <div className="space-y-4">
                <Input
                  type="text"
                  placeholder="البحث في الحافظة..."
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                  className="bg-black/20 border-white/10"
                />
                
                <div className="flex gap-4">
                  <Textarea
                    placeholder="أضف محتوى جديد للحافظة..."
                    value={newContent}
                    onChange={(e) => setNewContent(e.target.value)}
                    className="bg-black/20 border-white/10 flex-1"
                    rows={2}
                  />
                  <div className="flex flex-col gap-2">
                    <select
                      value={contentType}
                      onChange={(e) => setContentType(e.target.value)}
                      className="bg-black/20 border border-white/10 rounded-lg px-3 py-2 text-white"
                    >
                      <option value="auto">تلقائي</option>
                      <option value="text">نص</option>
                      <option value="url">رابط</option>
                      <option value="email">بريد إلكتروني</option>
                      <option value="phone">هاتف</option>
                      <option value="code">كود</option>
                      <option value="password">كلمة مرور</option>
                    </select>
                    <Button
                      onClick={handleAddItem}
                      disabled={!newContent.trim() || addItemMutation.isPending}
                      className="bg-gradient-to-r from-[hsl(var(--electric-blue))] to-[hsl(var(--deep-purple))] hover-glow"
                    >
                      <i className="fas fa-plus mr-2"></i>
                      إضافة
                    </Button>
                  </div>
                </div>
              </div>
            </motion.div>

            {/* قائمة العناصر */}
            <div className="space-y-4">
              <AnimatePresence>
                {filteredItems.map((item, index) => (
                  <motion.div
                    key={item.id}
                    initial={{ opacity: 0, y: 20 }}
                    animate={{ opacity: 1, y: 0 }}
                    exit={{ opacity: 0, x: -20 }}
                    transition={{ delay: index * 0.1 }}
                    className={`glass-morphism rounded-xl p-4 cursor-pointer transition-all duration-300 ${
                      selectedItem?.id === item.id ? 'ring-2 ring-[hsl(var(--electric-blue))]' : ''
                    }`}
                    onClick={() => setSelectedItem(item)}
                  >
                    <div className="flex items-start justify-between">
                      <div className="flex-1">
                        <div className="flex items-center gap-3 mb-2">
                          <i className={`${getContentIcon(item.contentType)} ${getContentColor(item.contentType)}`}></i>
                          <Badge variant="outline" className="text-xs">
                            {item.contentType}
                          </Badge>
                          {item.isFavorite && (
                            <i className="fas fa-star text-yellow-400"></i>
                          )}
                        </div>
                        <p className="text-white text-sm line-clamp-2 mb-2">
                          {item.content}
                        </p>
                        <div className="flex items-center gap-4 text-xs text-gray-400">
                          <span>
                            {formatDistanceToNow(new Date(item.createdAt || Date.now()), { 
                              addSuffix: true, 
                              locale: ar 
                            })}
                          </span>
                          <span>مرات الوصول: {item.accessCount}</span>
                        </div>
                      </div>
                      <div className="flex gap-2">
                        <Button
                          size="sm"
                          variant="ghost"
                          onClick={(e) => {
                            e.stopPropagation();
                            copyToClipboard(item.content);
                          }}
                          className="hover:bg-[hsl(var(--electric-blue))]/20"
                        >
                          <i className="fas fa-copy"></i>
                        </Button>
                        <Button
                          size="sm"
                          variant="ghost"
                          onClick={(e) => {
                            e.stopPropagation();
                            toggleFavoriteMutation.mutate({
                              id: item.id,
                              isFavorite: item.isFavorite || false
                            });
                          }}
                          className="hover:bg-yellow-500/20"
                        >
                          <i className={`fas fa-star ${item.isFavorite ? 'text-yellow-400' : 'text-gray-400'}`}></i>
                        </Button>
                      </div>
                    </div>
                  </motion.div>
                ))}
              </AnimatePresence>
            </div>

            {filteredItems.length === 0 && (
              <motion.div
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                className="glass-morphism rounded-2xl p-12 text-center"
              >
                <i className="fas fa-clipboard text-6xl text-gray-500 mb-4"></i>
                <h3 className="text-xl font-bold text-gray-300 mb-2">
                  {searchTerm ? "لا توجد نتائج" : "الحافظة فارغة"}
                </h3>
                <p className="text-gray-400">
                  {searchTerm ? "جرب مصطلح بحث مختلف" : "ابدأ بإضافة محتوى جديد"}
                </p>
              </motion.div>
            )}
          </div>

          {/* التفاصيل والتحليل */}
          <div>
            {selectedItem ? (
              <motion.div
                initial={{ opacity: 0, x: 20 }}
                animate={{ opacity: 1, x: 0 }}
                className="glass-morphism rounded-2xl p-6 sticky top-24"
              >
                <div className="flex items-center justify-between mb-4">
                  <h3 className="text-xl font-bold text-gradient">تفاصيل العنصر</h3>
                  <Button
                    size="sm"
                    variant="destructive"
                    onClick={() => deleteItemMutation.mutate(selectedItem.id)}
                    disabled={deleteItemMutation.isPending}
                  >
                    <i className="fas fa-trash"></i>
                  </Button>
                </div>

                <div className="space-y-4">
                  <div>
                    <label className="text-sm text-gray-400 block mb-1">المحتوى:</label>
                    <div className="bg-black/20 rounded-lg p-3 text-sm font-mono">
                      {selectedItem.content}
                    </div>
                  </div>

                  <div>
                    <label className="text-sm text-gray-400 block mb-1">النوع:</label>
                    <Badge className={getContentColor(selectedItem.contentType)}>
                      <i className={`${getContentIcon(selectedItem.contentType)} mr-2`}></i>
                      {selectedItem.contentType}
                    </Badge>
                  </div>

                  <div>
                    <label className="text-sm text-gray-400 block mb-1">الإحصائيات:</label>
                    <div className="grid grid-cols-2 gap-2 text-sm">
                      <div className="bg-black/20 rounded-lg p-2 text-center">
                        <div className="text-[hsl(var(--electric-blue))] font-bold">
                          {selectedItem.accessCount}
                        </div>
                        <div className="text-gray-400">مرات الوصول</div>
                      </div>
                      <div className="bg-black/20 rounded-lg p-2 text-center">
                        <div className="text-[hsl(var(--neon-green))] font-bold">
                          {selectedItem.content.length}
                        </div>
                        <div className="text-gray-400">حرف</div>
                      </div>
                    </div>
                  </div>

                  {selectedItem.aiAnalysis && (
                    <div>
                      <label className="text-sm text-gray-400 block mb-1">تحليل الذكاء الاصطناعي:</label>
                      <div className="bg-black/20 rounded-lg p-3 text-sm">
                        <pre className="whitespace-pre-wrap text-gray-300">
                          {typeof selectedItem.aiAnalysis === 'string' 
                            ? selectedItem.aiAnalysis 
                            : JSON.stringify(selectedItem.aiAnalysis, null, 2)}
                        </pre>
                      </div>
                    </div>
                  )}

                  <Button
                    onClick={() => copyToClipboard(selectedItem.content)}
                    className="w-full bg-gradient-to-r from-[hsl(var(--electric-blue))] to-[hsl(var(--deep-purple))] hover-glow"
                  >
                    <i className="fas fa-copy mr-2"></i>
                    نسخ المحتوى
                  </Button>
                </div>
              </motion.div>
            ) : (
              <motion.div
                initial={{ opacity: 0, x: 20 }}
                animate={{ opacity: 1, x: 0 }}
                className="glass-morphism rounded-2xl p-6 text-center sticky top-24"
              >
                <i className="fas fa-mouse-pointer text-4xl text-gray-500 mb-4"></i>
                <h3 className="text-lg font-bold text-gray-300 mb-2">اختر عنصراً</h3>
                <p className="text-gray-400 text-sm">انقر على أي عنصر في القائمة لرؤية التفاصيل</p>
              </motion.div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}