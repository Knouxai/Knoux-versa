import { useState } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Badge } from "@/components/ui/badge";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";
import { PasswordEntry } from "@shared/schema";
import { formatDistanceToNow } from "date-fns";
import { ar } from "date-fns/locale";

export default function PasswordManager() {
  const [selectedPassword, setSelectedPassword] = useState<PasswordEntry | null>(null);
  const [isAddingNew, setIsAddingNew] = useState(false);
  const [formData, setFormData] = useState({
    title: "",
    username: "",
    password: "",
    website: "",
    notes: ""
  });
  const [searchTerm, setSearchTerm] = useState("");
  const [showPassword, setShowPassword] = useState<Record<number, boolean>>({});
  const queryClient = useQueryClient();

  const { data: passwords = [], isLoading } = useQuery({
    queryKey: ['/api/passwords'],
    queryFn: () => apiRequest('/api/passwords'),
  });

  const addPasswordMutation = useMutation({
    mutationFn: (data: typeof formData) => 
      apiRequest('/api/passwords', { 
        method: 'POST', 
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(data) 
      }),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/passwords'] });
      setIsAddingNew(false);
      setFormData({ title: "", username: "", password: "", website: "", notes: "" });
    },
  });

  const deletePasswordMutation = useMutation({
    mutationFn: (id: number) => 
      apiRequest(`/api/passwords/${id}`, { method: 'DELETE' }),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/passwords'] });
      setSelectedPassword(null);
    },
  });

  const toggleFavoriteMutation = useMutation({
    mutationFn: ({ id, isFavorite }: { id: number; isFavorite: boolean }) => 
      apiRequest(`/api/passwords/${id}`, { 
        method: 'PATCH', 
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ isFavorite: !isFavorite }) 
      }),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/passwords'] });
    },
  });

  const copyToClipboard = async (text: string) => {
    try {
      await navigator.clipboard.writeText(text);
    } catch (error) {
      console.error('فشل في النسخ:', error);
    }
  };

  const generatePassword = () => {
    const chars = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789!@#$%^&*';
    let password = '';
    for (let i = 0; i < 16; i++) {
      password += chars.charAt(Math.floor(Math.random() * chars.length));
    }
    setFormData(prev => ({ ...prev, password }));
  };

  const getPasswordStrengthColor = (strength: number) => {
    if (strength >= 80) return 'text-green-400';
    if (strength >= 60) return 'text-yellow-400';
    if (strength >= 40) return 'text-orange-400';
    return 'text-red-400';
  };

  const getPasswordStrengthText = (strength: number) => {
    if (strength >= 80) return 'قوية جداً';
    if (strength >= 60) return 'قوية';
    if (strength >= 40) return 'متوسطة';
    return 'ضعيفة';
  };

  const filteredPasswords = Array.isArray(passwords) ? passwords.filter((password: PasswordEntry) =>
    password.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
    (password.username || '').toLowerCase().includes(searchTerm.toLowerCase()) ||
    (password.website || '').toLowerCase().includes(searchTerm.toLowerCase())
  ) : [];

  if (isLoading) {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center">
        <div className="glass-morphism rounded-2xl p-8">
          <div className="animate-spin w-8 h-8 border-2 border-[hsl(var(--electric-blue))] border-t-transparent rounded-full mx-auto"></div>
          <p className="text-center mt-4 text-gray-300">جاري تحميل مدير كلمات المرور...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-background pt-24 pb-12">
      <div className="max-w-7xl mx-auto px-6">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="text-center mb-12"
        >
          <h1 className="text-5xl font-black text-gradient mb-4">مدير كلمات المرور</h1>
          <p className="text-xl text-gray-300 max-w-2xl mx-auto">
            احفظ وأدِر كلمات المرور بأمان تام مع تشفير عسكري الدرجة
          </p>
        </motion.div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          <div className="lg:col-span-2">
            <motion.div
              initial={{ opacity: 0, x: -20 }}
              animate={{ opacity: 1, x: 0 }}
              className="glass-morphism rounded-2xl p-6 mb-6"
            >
              <div className="flex items-center justify-between mb-4">
                <Input
                  type="text"
                  placeholder="البحث في كلمات المرور..."
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                  className="bg-black/20 border-white/10 flex-1 mr-4"
                />
                <Button
                  onClick={() => setIsAddingNew(true)}
                  className="bg-gradient-to-r from-[hsl(var(--electric-blue))] to-[hsl(var(--deep-purple))] hover-glow"
                >
                  <i className="fas fa-plus mr-2"></i>
                  إضافة كلمة مرور
                </Button>
              </div>
            </motion.div>

            <div className="space-y-4">
              <AnimatePresence>
                {filteredPasswords.map((password: PasswordEntry, index: number) => (
                  <motion.div
                    key={password.id}
                    initial={{ opacity: 0, y: 20 }}
                    animate={{ opacity: 1, y: 0 }}
                    exit={{ opacity: 0, x: -20 }}
                    transition={{ delay: index * 0.1 }}
                    className={`glass-morphism rounded-xl p-6 cursor-pointer transition-all duration-300 ${
                      selectedPassword?.id === password.id ? 'ring-2 ring-[hsl(var(--electric-blue))]' : ''
                    }`}
                    onClick={() => setSelectedPassword(password)}
                  >
                    <div className="flex items-start justify-between">
                      <div className="flex-1">
                        <div className="flex items-center gap-3 mb-3">
                          <div className="w-10 h-10 bg-gradient-to-r from-[hsl(var(--electric-blue))] to-[hsl(var(--deep-purple))] rounded-lg flex items-center justify-center">
                            <i className="fas fa-key text-white"></i>
                          </div>
                          <div>
                            <h3 className="font-bold text-white">{password.title}</h3>
                            {password.username && (
                              <p className="text-sm text-gray-400">{password.username}</p>
                            )}
                          </div>
                          {password.isFavorite && (
                            <i className="fas fa-star text-yellow-400"></i>
                          )}
                        </div>
                        
                        <div className="flex items-center gap-4 text-sm text-gray-400 mb-3">
                          {password.website && (
                            <span className="flex items-center gap-2">
                              <i className="fas fa-globe"></i>
                              {password.website}
                            </span>
                          )}
                          <span className="flex items-center gap-2">
                            <i className="fas fa-shield-alt"></i>
                            <span className={getPasswordStrengthColor(password.passwordStrength || 0)}>
                              {getPasswordStrengthText(password.passwordStrength || 0)}
                            </span>
                          </span>
                        </div>

                        <div className="flex items-center gap-2">
                          <Badge variant={password.breachStatus === 'safe' ? 'default' : 'destructive'}>
                            {password.breachStatus === 'safe' ? 'آمنة' : 'مخترقة'}
                          </Badge>
                          <span className="text-xs text-gray-500">
                            {formatDistanceToNow(new Date(password.createdAt || Date.now()), { 
                              addSuffix: true, 
                              locale: ar 
                            })}
                          </span>
                        </div>
                      </div>

                      <div className="flex gap-2">
                        <Button
                          size="sm"
                          variant="ghost"
                          onClick={(e) => {
                            e.stopPropagation();
                            copyToClipboard(password.username || '');
                          }}
                          className="hover:bg-[hsl(var(--electric-blue))]/20"
                        >
                          <i className="fas fa-user"></i>
                        </Button>
                        <Button
                          size="sm"
                          variant="ghost"
                          onClick={(e) => {
                            e.stopPropagation();
                            // في تطبيق حقيقي، ستحتاج لفك تشفير كلمة المرور
                            copyToClipboard('••••••••');
                          }}
                          className="hover:bg-[hsl(var(--neon-pink))]/20"
                        >
                          <i className="fas fa-key"></i>
                        </Button>
                        <Button
                          size="sm"
                          variant="ghost"
                          onClick={(e) => {
                            e.stopPropagation();
                            toggleFavoriteMutation.mutate({
                              id: password.id,
                              isFavorite: password.isFavorite || false
                            });
                          }}
                          className="hover:bg-yellow-500/20"
                        >
                          <i className={`fas fa-star ${password.isFavorite ? 'text-yellow-400' : 'text-gray-400'}`}></i>
                        </Button>
                      </div>
                    </div>
                  </motion.div>
                ))}
              </AnimatePresence>
            </div>

            {filteredPasswords.length === 0 && (
              <motion.div
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                className="glass-morphism rounded-2xl p-12 text-center"
              >
                <i className="fas fa-key text-6xl text-gray-500 mb-4"></i>
                <h3 className="text-xl font-bold text-gray-300 mb-2">
                  {searchTerm ? "لا توجد كلمات مرور مطابقة" : "لا توجد كلمات مرور محفوظة"}
                </h3>
                <p className="text-gray-400">
                  {searchTerm ? "جرب مصطلح بحث مختلف" : "ابدأ بإضافة كلمة مرور جديدة"}
                </p>
              </motion.div>
            )}
          </div>

          <div>
            {isAddingNew ? (
              <motion.div
                initial={{ opacity: 0, x: 20 }}
                animate={{ opacity: 1, x: 0 }}
                className="glass-morphism rounded-2xl p-6 sticky top-24"
              >
                <div className="flex items-center justify-between mb-6">
                  <h3 className="text-xl font-bold text-gradient">إضافة كلمة مرور جديدة</h3>
                  <Button
                    size="sm"
                    variant="ghost"
                    onClick={() => setIsAddingNew(false)}
                  >
                    <i className="fas fa-times"></i>
                  </Button>
                </div>

                <div className="space-y-4">
                  <Input
                    placeholder="العنوان (مطلوب)"
                    value={formData.title}
                    onChange={(e) => setFormData(prev => ({ ...prev, title: e.target.value }))}
                    className="bg-black/20 border-white/10"
                  />
                  
                  <Input
                    placeholder="اسم المستخدم"
                    value={formData.username}
                    onChange={(e) => setFormData(prev => ({ ...prev, username: e.target.value }))}
                    className="bg-black/20 border-white/10"
                  />
                  
                  <div className="relative">
                    <Input
                      type={showPassword[0] ? "text" : "password"}
                      placeholder="كلمة المرور (مطلوبة)"
                      value={formData.password}
                      onChange={(e) => setFormData(prev => ({ ...prev, password: e.target.value }))}
                      className="bg-black/20 border-white/10 pr-20"
                    />
                    <div className="absolute left-2 top-1/2 -translate-y-1/2 flex gap-1">
                      <Button
                        size="sm"
                        variant="ghost"
                        onClick={() => setShowPassword(prev => ({ ...prev, 0: !prev[0] }))}
                      >
                        <i className={`fas ${showPassword[0] ? 'fa-eye-slash' : 'fa-eye'}`}></i>
                      </Button>
                      <Button
                        size="sm"
                        variant="ghost"
                        onClick={generatePassword}
                      >
                        <i className="fas fa-magic"></i>
                      </Button>
                    </div>
                  </div>
                  
                  <Input
                    placeholder="الموقع الإلكتروني"
                    value={formData.website}
                    onChange={(e) => setFormData(prev => ({ ...prev, website: e.target.value }))}
                    className="bg-black/20 border-white/10"
                  />
                  
                  <Textarea
                    placeholder="ملاحظات إضافية"
                    value={formData.notes}
                    onChange={(e) => setFormData(prev => ({ ...prev, notes: e.target.value }))}
                    className="bg-black/20 border-white/10"
                    rows={3}
                  />

                  <Button
                    onClick={() => addPasswordMutation.mutate(formData)}
                    disabled={!formData.title || !formData.password || addPasswordMutation.isPending}
                    className="w-full bg-gradient-to-r from-[hsl(var(--electric-blue))] to-[hsl(var(--deep-purple))] hover-glow"
                  >
                    <i className="fas fa-save mr-2"></i>
                    حفظ كلمة المرور
                  </Button>
                </div>
              </motion.div>
            ) : selectedPassword ? (
              <motion.div
                initial={{ opacity: 0, x: 20 }}
                animate={{ opacity: 1, x: 0 }}
                className="glass-morphism rounded-2xl p-6 sticky top-24"
              >
                <div className="flex items-center justify-between mb-6">
                  <h3 className="text-xl font-bold text-gradient">تفاصيل كلمة المرور</h3>
                  <Button
                    size="sm"
                    variant="destructive"
                    onClick={() => deletePasswordMutation.mutate(selectedPassword.id)}
                    disabled={deletePasswordMutation.isPending}
                  >
                    <i className="fas fa-trash"></i>
                  </Button>
                </div>

                <div className="space-y-4">
                  <div>
                    <label className="text-sm text-gray-400 block mb-2">العنوان:</label>
                    <div className="bg-black/20 rounded-lg p-3 text-white">
                      {selectedPassword.title}
                    </div>
                  </div>

                  {selectedPassword.username && (
                    <div>
                      <label className="text-sm text-gray-400 block mb-2">اسم المستخدم:</label>
                      <div className="bg-black/20 rounded-lg p-3 text-white flex items-center justify-between">
                        <span>{selectedPassword.username}</span>
                        <Button
                          size="sm"
                          variant="ghost"
                          onClick={() => copyToClipboard(selectedPassword.username || '')}
                        >
                          <i className="fas fa-copy"></i>
                        </Button>
                      </div>
                    </div>
                  )}

                  <div>
                    <label className="text-sm text-gray-400 block mb-2">كلمة المرور:</label>
                    <div className="bg-black/20 rounded-lg p-3 text-white flex items-center justify-between">
                      <span className="font-mono">
                        {showPassword[selectedPassword.id] ? selectedPassword.encryptedPassword.substring(0, 16) + '...' : '••••••••••••••••'}
                      </span>
                      <div className="flex gap-2">
                        <Button
                          size="sm"
                          variant="ghost"
                          onClick={() => setShowPassword(prev => ({ 
                            ...prev, 
                            [selectedPassword.id]: !prev[selectedPassword.id] 
                          }))}
                        >
                          <i className={`fas ${showPassword[selectedPassword.id] ? 'fa-eye-slash' : 'fa-eye'}`}></i>
                        </Button>
                        <Button
                          size="sm"
                          variant="ghost"
                          onClick={() => copyToClipboard('••••••••')}
                        >
                          <i className="fas fa-copy"></i>
                        </Button>
                      </div>
                    </div>
                  </div>

                  <div>
                    <label className="text-sm text-gray-400 block mb-2">قوة كلمة المرور:</label>
                    <div className="flex items-center gap-3">
                      <div className="flex-1 bg-black/20 rounded-full h-2">
                        <div 
                          className={`h-full rounded-full transition-all duration-300 ${
                            (selectedPassword.passwordStrength || 0) >= 80 ? 'bg-green-400' :
                            (selectedPassword.passwordStrength || 0) >= 60 ? 'bg-yellow-400' :
                            (selectedPassword.passwordStrength || 0) >= 40 ? 'bg-orange-400' : 'bg-red-400'
                          }`}
                          style={{ width: `${selectedPassword.passwordStrength || 0}%` }}
                        ></div>
                      </div>
                      <span className={`text-sm ${getPasswordStrengthColor(selectedPassword.passwordStrength || 0)}`}>
                        {getPasswordStrengthText(selectedPassword.passwordStrength || 0)}
                      </span>
                    </div>
                  </div>

                  {selectedPassword.website && (
                    <div>
                      <label className="text-sm text-gray-400 block mb-2">الموقع:</label>
                      <div className="bg-black/20 rounded-lg p-3 text-white">
                        <a 
                          href={selectedPassword.website.startsWith('http') ? selectedPassword.website : `https://${selectedPassword.website}`}
                          target="_blank"
                          rel="noopener noreferrer"
                          className="text-[hsl(var(--electric-blue))] hover:underline"
                        >
                          {selectedPassword.website}
                        </a>
                      </div>
                    </div>
                  )}

                  {selectedPassword.notes && (
                    <div>
                      <label className="text-sm text-gray-400 block mb-2">الملاحظات:</label>
                      <div className="bg-black/20 rounded-lg p-3 text-white whitespace-pre-wrap">
                        {selectedPassword.notes}
                      </div>
                    </div>
                  )}
                </div>
              </motion.div>
            ) : (
              <motion.div
                initial={{ opacity: 0, x: 20 }}
                animate={{ opacity: 1, x: 0 }}
                className="glass-morphism rounded-2xl p-6 text-center sticky top-24"
              >
                <i className="fas fa-mouse-pointer text-4xl text-gray-500 mb-4"></i>
                <h3 className="text-lg font-bold text-gray-300 mb-2">اختر كلمة مرور</h3>
                <p className="text-gray-400 text-sm">انقر على أي كلمة مرور في القائمة لرؤية التفاصيل</p>
              </motion.div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}