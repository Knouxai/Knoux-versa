import { Navigation } from "@/components/Navigation";
import { GoldenMembership } from "@/components/GoldenMembership";

export default function Membership() {
  return (
    <div className="min-h-screen bg-[hsl(var(--background))] text-white">
      <Navigation />
      <main className="pt-20">
        <GoldenMembership />
      </main>
    </div>
  );
}
