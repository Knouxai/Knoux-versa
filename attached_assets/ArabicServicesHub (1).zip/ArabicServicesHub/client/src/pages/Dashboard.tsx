import { Navigation } from "@/components/Navigation";
import { Hero } from "@/components/Hero";
import { ServiceGrid } from "@/components/ServiceGrid";
import { ClipboardDemo } from "@/components/ClipboardDemo";
import { GoldenMembership } from "@/components/GoldenMembership";
import { ContactSection } from "@/components/ContactSection";
import { motion } from "framer-motion";
import { STATS } from "@/lib/constants";

export default function Dashboard() {
  return (
    <div className="min-h-screen bg-[hsl(var(--background))] text-white overflow-x-hidden">
      <Navigation />
      
      <main>
        <Hero />
        <ServiceGrid />
        <ClipboardDemo />
        <GoldenMembership />
        
        {/* Security Stats */}
        <section className="py-20 bg-gradient-to-r from-[hsl(var(--background))] via-[hsl(var(--deep-purple))]/20 to-[hsl(var(--background))]">
          <div className="max-w-7xl mx-auto px-6">
            <motion.div 
              className="text-center mb-16"
              initial={{ opacity: 0, y: 30 }}
              whileInView={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.8 }}
              viewport={{ once: true }}
            >
              <h2 className="text-4xl md:text-5xl font-bold mb-6">
                <span className="text-gradient">
                  Trusted Worldwide
                </span>
              </h2>
              <p className="text-xl text-gray-400">Join millions of users who trust KNOUX for their digital security</p>
            </motion.div>
            
            <motion.div 
              className="grid grid-cols-2 md:grid-cols-4 gap-8"
              initial={{ opacity: 0 }}
              whileInView={{ opacity: 1 }}
              transition={{ duration: 0.8, staggerChildren: 0.2 }}
              viewport={{ once: true }}
            >
              {STATS.map((stat, index) => (
                <motion.div
                  key={index}
                  className="text-center"
                  initial={{ opacity: 0, y: 30 }}
                  whileInView={{ opacity: 1, y: 0 }}
                  transition={{ duration: 0.5, delay: index * 0.2 }}
                  viewport={{ once: true }}
                >
                  <div className={`text-4xl md:text-5xl font-black ${stat.color} mb-2`}>{stat.value}</div>
                  <p className="text-gray-400">{stat.label}</p>
                </motion.div>
              ))}
            </motion.div>
          </div>
        </section>

        <ContactSection />
      </main>

      {/* Footer */}
      <footer className="glass-morphism border-t border-white/10 py-12">
        <div className="max-w-7xl mx-auto px-6">
          <div className="grid grid-cols-1 md:grid-cols-4 gap-8 mb-8">
            <div>
              <div className="flex items-center space-x-3 mb-4">
                <div className="w-10 h-10 rounded-lg bg-gradient-to-br from-[hsl(var(--electric-blue))] via-[hsl(var(--deep-purple))] to-[hsl(var(--neon-pink))] animate-glow flex items-center justify-center">
                  <i className="fas fa-shield-halved text-lg text-white"></i>
                </div>
                <span className="text-xl font-bold text-gradient">KNOUX</span>
              </div>
              <p className="text-gray-400 text-sm mb-4">Ultimate encryption and security suite for the modern digital world.</p>
              <div className="flex space-x-4">
                {['twitter', 'facebook', 'linkedin', 'github'].map((social) => (
                  <a key={social} href="#" className="text-gray-400 hover:text-[hsl(var(--electric-blue))] transition-colors">
                    <i className={`fab fa-${social}`}></i>
                  </a>
                ))}
              </div>
            </div>
            
            <div>
              <h4 className="font-bold mb-4">Products</h4>
              <ul className="space-y-2 text-sm">
                {['File Encryption', 'Password Manager', 'Secure VPN', 'AI Clipboard', 'Dark Web Monitor'].map((product) => (
                  <li key={product}>
                    <a href="#" className="text-gray-400 hover:text-white transition-colors">{product}</a>
                  </li>
                ))}
              </ul>
            </div>
            
            <div>
              <h4 className="font-bold mb-4">Support</h4>
              <ul className="space-y-2 text-sm">
                {['Help Center', 'Contact Support', 'System Status', 'Security Audit', 'Bug Bounty'].map((support) => (
                  <li key={support}>
                    <a href="#" className="text-gray-400 hover:text-white transition-colors">{support}</a>
                  </li>
                ))}
              </ul>
            </div>
            
            <div>
              <h4 className="font-bold mb-4">Company</h4>
              <ul className="space-y-2 text-sm">
                {['About Us', 'Privacy Policy', 'Terms of Service', 'Careers', 'Press Kit'].map((company) => (
                  <li key={company}>
                    <a href="#" className="text-gray-400 hover:text-white transition-colors">{company}</a>
                  </li>
                ))}
              </ul>
            </div>
          </div>
          
          <div className="border-t border-white/10 pt-8 flex flex-col md:flex-row justify-between items-center">
            <p className="text-gray-400 text-sm">&copy; 2025 KNOUX Security Systems. All rights reserved.</p>
            <div className="flex items-center space-x-4 mt-4 md:mt-0">
              <span className="text-sm text-gray-400">Secured by</span>
              <div className="flex items-center space-x-2">
                <i className="fas fa-shield-alt text-[hsl(var(--neon-green))]"></i>
                <span className="text-sm font-medium text-[hsl(var(--neon-green))]">Quantum Encryption</span>
              </div>
            </div>
          </div>
        </div>
      </footer>
    </div>
  );
}
