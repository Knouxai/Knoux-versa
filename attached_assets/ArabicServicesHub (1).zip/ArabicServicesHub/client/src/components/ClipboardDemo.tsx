import { useState } from "react";
import { motion } from "framer-motion";
import { GlassCard } from "@/components/ui/glass-card";
import { Input } from "@/components/ui/input";
import { CLIPBOARD_DEMO_ITEMS } from "@/lib/constants";

export function ClipboardDemo() {
  const [selectedItem, setSelectedItem] = useState<number | null>(null);

  return (
    <section id="clipboard" className="py-20 bg-gradient-to-b from-[hsl(var(--background))]/50 to-transparent">
      <div className="max-w-7xl mx-auto px-6">
        <motion.div 
          className="text-center mb-16"
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8 }}
          viewport={{ once: true }}
        >
          <h2 className="text-4xl md:text-5xl font-bold mb-6 text-gradient">
            AI-Powered Clipboard Revolution
          </h2>
          <p className="text-xl text-gray-400 max-w-3xl mx-auto">
            Experience the future of clipboard management with intelligent content analysis, smart categorization, and seamless cross-device synchronization
          </p>
        </motion.div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center mb-16">
          {/* Clipboard Demo Interface */}
          <motion.div
            initial={{ opacity: 0, x: -50 }}
            whileInView={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.8 }}
            viewport={{ once: true }}
          >
            <GlassCard className="p-8 space-y-6">
              <div className="flex items-center justify-between mb-6">
                <h3 className="text-2xl font-bold">Smart Clipboard History</h3>
                <div className="flex items-center space-x-2">
                  <div className="w-3 h-3 bg-[hsl(var(--neon-green))] rounded-full animate-pulse"></div>
                  <span className="text-sm text-[hsl(var(--neon-green))]">AI Active</span>
                </div>
              </div>
              
              {/* Clipboard Items */}
              <div className="space-y-4 max-h-96 overflow-y-auto custom-scrollbar">
                {CLIPBOARD_DEMO_ITEMS.map((item, index) => (
                  <motion.div
                    key={item.id}
                    className={`glass-morphism rounded-xl p-4 cursor-pointer transition-all ${
                      selectedItem === item.id ? 'ring-2 ring-[hsl(var(--electric-blue))]' : ''
                    }`}
                    onClick={() => setSelectedItem(item.id)}
                    whileHover={{ scale: 1.02 }}
                    initial={{ opacity: 0, y: 20 }}
                    whileInView={{ opacity: 1, y: 0 }}
                    transition={{ duration: 0.5, delay: index * 0.1 }}
                    viewport={{ once: true }}
                  >
                    <div className="flex items-start space-x-3">
                      <div className={`w-10 h-10 bg-gradient-to-r ${item.color} rounded-lg flex items-center justify-center`}>
                        <i className={`fas fa-${item.icon} text-white text-sm`}></i>
                      </div>
                      <div className="flex-1">
                        <div className="flex items-center justify-between mb-2">
                          <span className={`text-sm font-medium text-${item.color.split('-')[1]}-400`}>{item.type}</span>
                          <span className="text-xs text-gray-500">{item.time}</span>
                        </div>
                        <p className="text-sm text-gray-300 truncate">{item.content}</p>
                        <div className="flex items-center space-x-2 mt-2">
                          {item.tags.map((tag, tagIndex) => (
                            <span 
                              key={tagIndex}
                              className={`text-xs bg-${item.color.split('-')[1]}-500/20 text-${item.color.split('-')[1]}-300 px-2 py-1 rounded`}
                            >
                              {tag}
                            </span>
                          ))}
                        </div>
                      </div>
                    </div>
                  </motion.div>
                ))}
              </div>
              
              {/* Search Bar */}
              <div className="relative">
                <Input 
                  placeholder="Search clipboard history..." 
                  className="glass-morphism bg-transparent border-white/10 focus:border-[hsl(var(--electric-blue))]/50"
                />
                <i className="fas fa-search absolute right-4 top-1/2 transform -translate-y-1/2 text-gray-400"></i>
              </div>
            </GlassCard>
          </motion.div>

          {/* Features List */}
          <motion.div 
            className="space-y-8"
            initial={{ opacity: 0, x: 50 }}
            whileInView={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.8 }}
            viewport={{ once: true }}
          >
            {[
              {
                icon: 'brain',
                title: 'Intelligent Content Recognition',
                description: 'AI automatically categorizes and tags your clipboard content - URLs, code snippets, passwords, images, and more.',
                color: 'from-[hsl(var(--electric-blue))] to-cyan-400'
              },
              {
                icon: 'search',
                title: 'Smart Search & Filtering',
                description: 'Find any clipboard item instantly with natural language search and advanced filtering options.',
                color: 'from-[hsl(var(--deep-purple))] to-violet-500'
              },
              {
                icon: 'sync',
                title: 'Cross-Device Synchronization',
                description: 'Access your clipboard history across all devices with end-to-end encryption and real-time sync.',
                color: 'from-[hsl(var(--neon-pink))] to-rose-500'
              },
              {
                icon: 'shield-alt',
                title: 'Automatic Security Handling',
                description: 'Sensitive content like passwords and API keys are automatically encrypted and marked for secure handling.',
                color: 'from-emerald-500 to-green-500'
              }
            ].map((feature, index) => (
              <motion.div 
                key={index}
                className="flex items-start space-x-4"
                initial={{ opacity: 0, x: 30 }}
                whileInView={{ opacity: 1, x: 0 }}
                transition={{ duration: 0.5, delay: index * 0.2 }}
                viewport={{ once: true }}
              >
                <div className={`w-12 h-12 bg-gradient-to-r ${feature.color} rounded-xl flex items-center justify-center flex-shrink-0`}>
                  <i className={`fas fa-${feature.icon} text-lg text-white`}></i>
                </div>
                <div>
                  <h4 className="text-xl font-bold mb-2">{feature.title}</h4>
                  <p className="text-gray-400">{feature.description}</p>
                </div>
              </motion.div>
            ))}
          </motion.div>
        </div>
      </div>
    </section>
  );
}
