import { Button } from "@/components/ui/button";
import { motion } from "framer-motion";
import { KnoxLogo } from "./KnoxLogo";

export function Hero() {
  return (
    <section className="relative overflow-hidden min-h-screen flex items-center justify-center pt-20">
      {/* خلفية متحركة متقدمة */}
      <div className="absolute inset-0">
        <div className="absolute inset-0 bg-gradient-to-br from-[hsl(var(--background))] via-[hsl(var(--deep-purple))]/20 to-[hsl(var(--background))] animate-gradient"></div>
        <div className="absolute top-20 left-20 w-72 h-72 bg-[hsl(var(--electric-blue))]/10 rounded-full blur-3xl animate-pulse"></div>
        <div className="absolute bottom-20 right-20 w-96 h-96 bg-[hsl(var(--neon-pink))]/10 rounded-full blur-3xl animate-pulse delay-1000"></div>
        <div className="absolute top-1/2 left-1/2 transform -translate-x-1/2 -translate-y-1/2 w-[800px] h-[800px] bg-gradient-conic from-[hsl(var(--electric-blue))]/5 via-[hsl(var(--deep-purple))]/5 to-[hsl(var(--neon-pink))]/5 rounded-full blur-3xl animate-spin opacity-30" style={{animationDuration: '20s'}}></div>
      </div>
      
      <div className="relative max-w-7xl mx-auto px-6 text-center z-10">
        <motion.div
          initial={{ opacity: 0, y: 50 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 1, ease: "easeOut" }}
        >
          {/* شعار KNOUX المركزي */}
          <div className="flex justify-center mb-8">
            <KnoxLogo size="xl" animated={true} showText={false} />
          </div>
          
          <motion.h1 
            className="text-7xl md:text-9xl font-black mb-6 text-gradient leading-tight"
            animate={{ 
              backgroundPosition: ["0% 50%", "100% 50%", "0% 50%"] 
            }}
            transition={{ 
              duration: 4, 
              repeat: Infinity, 
              ease: "linear" 
            }}
          >
            KNOUX
          </motion.h1>
          
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ delay: 0.5, duration: 0.8 }}
          >
            <h2 className="text-3xl md:text-4xl font-bold mb-4 text-gold-gradient">
              النظام الأمني الأكثر تطوراً في العالم
            </h2>
            <p className="text-xl md:text-2xl font-light mb-8 text-gray-300 max-w-4xl mx-auto">
              تشفير كمي متقدم • ذكاء اصطناعي دفاعي • حماية شاملة للخصوصية
            </p>
          </motion.div>
        </motion.div>
        
        <motion.div 
          className="flex flex-wrap justify-center gap-4 mb-12"
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ delay: 0.3, duration: 0.8 }}
        >
          <motion.div 
            className="glass-morphism rounded-full px-6 py-3 neon-border hover-glow cursor-pointer"
            whileHover={{ scale: 1.05 }}
          >
            <span className="text-sm font-medium text-[hsl(var(--electric-blue))] flex items-center gap-2">
              <i className="fas fa-atom"></i>
              تشفير كمي مقاوم للحاسوب الكمي
            </span>
          </motion.div>
          <motion.div 
            className="glass-morphism rounded-full px-6 py-3 neon-border hover-glow cursor-pointer"
            whileHover={{ scale: 1.05 }}
          >
            <span className="text-sm font-medium text-[hsl(var(--deep-purple))] flex items-center gap-2">
              <i className="fas fa-brain"></i>
              ذكاء اصطناعي دفاعي متطور
            </span>
          </motion.div>
          <motion.div 
            className="glass-morphism rounded-full px-6 py-3 neon-border hover-glow cursor-pointer"
            whileHover={{ scale: 1.05 }}
          >
            <span className="text-sm font-medium text-[hsl(var(--neon-pink))] flex items-center gap-2">
              <i className="fas fa-sync-alt"></i>
              مزامنة فورية عبر جميع الأجهزة
            </span>
          </motion.div>
          <motion.div 
            className="glass-morphism rounded-full px-6 py-3 neon-border hover-glow cursor-pointer"
            whileHover={{ scale: 1.05 }}
          >
            <span className="text-sm font-medium text-[hsl(var(--premium-gold))] flex items-center gap-2">
              <i className="fas fa-shield-virus"></i>
              حماية عسكرية الدرجة
            </span>
          </motion.div>
        </motion.div>

        {/* أزرار العمل الرئيسية */}
        <motion.div 
          className="flex flex-col sm:flex-row gap-6 justify-center mb-16"
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.7, duration: 0.8 }}
        >
          <motion.button
            className="group relative px-8 py-4 bg-gradient-to-r from-[hsl(var(--electric-blue))] via-[hsl(var(--deep-purple))] to-[hsl(var(--neon-pink))] rounded-2xl font-bold text-lg hover-glow overflow-hidden"
            whileHover={{ scale: 1.05 }}
            whileTap={{ scale: 0.95 }}
          >
            <div className="absolute inset-0 bg-gradient-to-r from-[hsl(var(--electric-blue))] via-[hsl(var(--deep-purple))] to-[hsl(var(--neon-pink))] opacity-0 group-hover:opacity-100 transition-opacity duration-300"></div>
            <span className="relative z-10 flex items-center gap-3">
              <i className="fas fa-rocket"></i>
              ابدأ الحماية المجانية
            </span>
          </motion.button>
          
          <motion.button
            className="group relative px-8 py-4 glass-morphism border-2 border-[hsl(var(--premium-gold))]/30 rounded-2xl font-bold text-lg hover-glow"
            whileHover={{ scale: 1.05 }}
            whileTap={{ scale: 0.95 }}
          >
            <span className="relative z-10 flex items-center gap-3 text-[hsl(var(--premium-gold))]">
              <i className="fas fa-crown"></i>
              العضوية الذهبية
            </span>
          </motion.button>
        </motion.div>

        {/* إحصائيات متحركة */}
        <motion.div 
          className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-6 max-w-6xl mx-auto mb-16"
          initial={{ opacity: 0, y: 30 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.9, duration: 0.8 }}
        >
          <motion.div 
            className="text-center glass-morphism rounded-2xl p-6 hover-glow group"
            whileHover={{ scale: 1.05, y: -5 }}
          >
            <div className="mb-3">
              <i className="fas fa-users text-3xl text-[hsl(var(--electric-blue))] group-hover:animate-pulse"></i>
            </div>
            <div className="text-3xl font-bold text-[hsl(var(--electric-blue))] mb-2">5.7M+</div>
            <div className="text-gray-400 text-sm">مستخدم نشط</div>
          </motion.div>
          
          <motion.div 
            className="text-center glass-morphism rounded-2xl p-6 hover-glow group"
            whileHover={{ scale: 1.05, y: -5 }}
          >
            <div className="mb-3">
              <i className="fas fa-heartbeat text-3xl text-[hsl(var(--neon-green))] group-hover:animate-pulse"></i>
            </div>
            <div className="text-3xl font-bold text-[hsl(var(--neon-green))] mb-2">99.99%</div>
            <div className="text-gray-400 text-sm">وقت التشغيل</div>
          </motion.div>
          
          <motion.div 
            className="text-center glass-morphism rounded-2xl p-6 hover-glow group"
            whileHover={{ scale: 1.05, y: -5 }}
          >
            <div className="mb-3">
              <i className="fas fa-shield-alt text-3xl text-[hsl(var(--premium-gold))] group-hover:animate-pulse"></i>
            </div>
            <div className="text-3xl font-bold text-[hsl(var(--premium-gold))] mb-2">2.8PB</div>
            <div className="text-gray-400 text-sm">بيانات محمية</div>
          </motion.div>
          
          <motion.div 
            className="text-center glass-morphism rounded-2xl p-6 hover-glow group"
            whileHover={{ scale: 1.05, y: -5 }}
          >
            <div className="mb-3">
              <i className="fas fa-globe-americas text-3xl text-[hsl(var(--deep-purple))] group-hover:animate-pulse"></i>
            </div>
            <div className="text-3xl font-bold text-[hsl(var(--deep-purple))] mb-2">195+</div>
            <div className="text-gray-400 text-sm">دولة</div>
          </motion.div>
          
          <motion.div 
            className="text-center glass-morphism rounded-2xl p-6 hover-glow group"
            whileHover={{ scale: 1.05, y: -5 }}
          >
            <div className="mb-3">
              <i className="fas fa-lock text-3xl text-emerald-400 group-hover:animate-pulse"></i>
            </div>
            <div className="text-3xl font-bold text-emerald-400 mb-2">0</div>
            <div className="text-gray-400 text-sm">انتهاكات أمنية</div>
          </motion.div>
          
          <motion.div 
            className="text-center glass-morphism rounded-2xl p-6 hover-glow group"
            whileHover={{ scale: 1.05, y: -5 }}
          >
            <div className="mb-3">
              <i className="fas fa-bolt text-3xl text-[hsl(var(--neon-pink))] group-hover:animate-pulse"></i>
            </div>
            <div className="text-3xl font-bold text-[hsl(var(--neon-pink))] mb-2">47ms</div>
            <div className="text-gray-400 text-sm">زمن التشفير</div>
          </motion.div>
        </motion.div>
        
        {/* الخدمات الأساسية */}
        <motion.div 
          className="grid grid-cols-1 md:grid-cols-3 gap-8 max-w-6xl mx-auto"
          initial={{ opacity: 0, y: 30 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 1.1, duration: 0.8 }}
        >
          <motion.div 
            className="glass-morphism rounded-2xl p-8 hover-glow group"
            whileHover={{ scale: 1.05, y: -10 }}
            transition={{ type: "spring", stiffness: 300 }}
          >
            <div className="w-20 h-20 mx-auto mb-6 bg-gradient-to-br from-[hsl(var(--electric-blue))] to-[hsl(var(--deep-purple))] rounded-2xl flex items-center justify-center group-hover:animate-pulse">
              <i className="fas fa-brain text-3xl text-white"></i>
            </div>
            <h3 className="text-2xl font-bold mb-4 text-center text-gradient">مدير الحافظة الذكي</h3>
            <p className="text-gray-400 text-center leading-relaxed">تحليل ذكي للمحتوى مع تصنيف تلقائي وحماية متقدمة للبيانات الحساسة</p>
          </motion.div>
          
          <motion.div 
            className="glass-morphism rounded-2xl p-8 hover-glow group"
            whileHover={{ scale: 1.05, y: -10 }}
            transition={{ type: "spring", stiffness: 300 }}
          >
            <div className="w-20 h-20 mx-auto mb-6 bg-gradient-to-br from-[hsl(var(--deep-purple))] to-[hsl(var(--neon-pink))] rounded-2xl flex items-center justify-center group-hover:animate-pulse">
              <i className="fas fa-atom text-3xl text-white"></i>
            </div>
            <h3 className="text-2xl font-bold mb-4 text-center text-gradient">الأمان الكمي</h3>
            <p className="text-gray-400 text-center leading-relaxed">تشفير الجيل القادم المقاوم للحاسوب الكمي مع حماية عسكرية الدرجة</p>
          </motion.div>
          
          <motion.div 
            className="glass-morphism rounded-2xl p-8 hover-glow group"
            whileHover={{ scale: 1.05, y: -10 }}
            transition={{ type: "spring", stiffness: 300 }}
          >
            <div className="w-20 h-20 mx-auto mb-6 bg-gradient-to-br from-[hsl(var(--neon-pink))] to-[hsl(var(--premium-gold))] rounded-2xl flex items-center justify-center group-hover:animate-pulse">
              <i className="fas fa-sync-alt text-3xl text-white"></i>
            </div>
            <h3 className="text-2xl font-bold mb-4 text-center text-gradient">المزامنة الشاملة</h3>
            <p className="text-gray-400 text-center leading-relaxed">مزامنة فورية عبر جميع الأجهزة مع تشفير طرف إلى طرف متقدم</p>
          </motion.div>
        </motion.div>
      </div>
    </section>
  );
}
