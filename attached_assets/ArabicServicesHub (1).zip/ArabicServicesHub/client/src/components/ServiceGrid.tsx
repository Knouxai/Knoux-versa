import { motion } from "framer-motion";
import { GlassCard } from "@/components/ui/glass-card";
import { Button } from "@/components/ui/button";
import { SERVICES, QUICK_ACTIONS } from "@/lib/constants";

export function ServiceGrid() {
  return (
    <section id="services" className="py-20 bg-gradient-to-b from-transparent to-[hsl(var(--background))]/50">
      <div className="max-w-7xl mx-auto px-6">
        <motion.div 
          className="text-center mb-16"
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8 }}
          viewport={{ once: true }}
        >
          <h2 className="text-4xl md:text-5xl font-bold mb-6 text-gradient">
            Complete Security Arsenal
          </h2>
          <p className="text-xl text-gray-400 max-w-2xl mx-auto">
            Comprehensive protection suite with cutting-edge technologies and AI-powered features
          </p>
        </motion.div>

        {/* Services Grid */}
        <motion.div 
          className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6 mb-16"
          initial={{ opacity: 0 }}
          whileInView={{ opacity: 1 }}
          transition={{ duration: 0.8, staggerChildren: 0.1 }}
          viewport={{ once: true }}
        >
          {SERVICES.map((service, index) => (
            <motion.div
              key={service.id}
              initial={{ opacity: 0, y: 30 }}
              whileInView={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.5, delay: index * 0.1 }}
              viewport={{ once: true }}
            >
              <GlassCard className="p-6 h-full" hover animate>
                <div className="flex items-center mb-4">
                  <div className={`w-12 h-12 bg-gradient-to-r ${service.color} rounded-xl flex items-center justify-center mr-4`}>
                    <i className={`fas fa-${service.icon} text-lg text-white`}></i>
                  </div>
                  <div>
                    <h3 className="font-bold text-lg">{service.title}</h3>
                    <p className="text-xs text-gray-400">{service.subtitle}</p>
                  </div>
                </div>
                <p className="text-sm text-gray-300 mb-4">{service.description}</p>
                <div className="flex items-center justify-between">
                  <span className={`text-xs ${service.statusColor} font-medium`}>• {service.status}</span>
                  <Button variant="ghost" size="sm" className="hover:text-[hsl(var(--electric-blue))]">
                    <i className="fas fa-arrow-right"></i>
                  </Button>
                </div>
              </GlassCard>
            </motion.div>
          ))}
        </motion.div>

        {/* Quick Actions */}
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8 }}
          viewport={{ once: true }}
        >
          <GlassCard className="p-8">
            <h3 className="text-2xl font-bold mb-6 text-center">Quick Security Actions</h3>
            <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
              {QUICK_ACTIONS.map((action, index) => (
                <motion.button
                  key={action.id}
                  className="glass-morphism rounded-xl p-4 hover-glow group transition-all"
                  whileHover={{ scale: 1.05 }}
                  whileTap={{ scale: 0.95 }}
                  initial={{ opacity: 0, y: 20 }}
                  whileInView={{ opacity: 1, y: 0 }}
                  transition={{ duration: 0.5, delay: index * 0.1 }}
                  viewport={{ once: true }}
                >
                  <i className={`fas fa-${action.icon} text-2xl ${action.color} mb-2 group-hover:scale-110 transition-transform`}></i>
                  <p className="text-sm font-medium">{action.title}</p>
                </motion.button>
              ))}
            </div>
          </GlassCard>
        </motion.div>
      </div>
    </section>
  );
}
