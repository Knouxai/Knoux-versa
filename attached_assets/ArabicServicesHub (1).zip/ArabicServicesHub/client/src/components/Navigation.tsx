import { useState, useEffect } from "react";
import { Button } from "@/components/ui/button";
import { motion } from "framer-motion";
import { KnoxLogo } from "./KnoxLogo";

export function Navigation() {
  const [scrolled, setScrolled] = useState(false);

  useEffect(() => {
    const handleScroll = () => {
      setScrolled(window.scrollY > 100);
    };

    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  const scrollTo = (elementId: string) => {
    const element = document.getElementById(elementId);
    if (element) {
      element.scrollIntoView({ behavior: 'smooth' });
    }
  };

  return (
    <motion.nav 
      className={`fixed top-0 left-0 right-0 z-50 transition-all duration-500 ${
        scrolled ? 'glass-morphism border-b border-white/10 backdrop-blur-xl' : 'bg-transparent'
      }`}
      initial={{ y: -100 }}
      animate={{ y: 0 }}
      transition={{ duration: 0.8, ease: "easeOut" }}
    >
      <div className="max-w-7xl mx-auto px-6 py-4">
        <div className="flex items-center justify-between">
          {/* KNOUX Logo */}
          <KnoxLogo size="md" animated={true} />

          {/* Navigation Links */}
          <div className="hidden md:flex items-center space-x-8">
            <motion.button 
              onClick={() => scrollTo('services')}
              className="relative text-gray-300 hover:text-[hsl(var(--electric-blue))] transition-all duration-300 font-medium group"
              whileHover={{ scale: 1.05 }}
            >
              الخدمات الأمنية
              <div className="absolute -bottom-1 left-0 w-0 h-0.5 bg-gradient-to-r from-[hsl(var(--electric-blue))] to-[hsl(var(--deep-purple))] group-hover:w-full transition-all duration-300"></div>
            </motion.button>
            <motion.button 
              onClick={() => scrollTo('clipboard')}
              className="relative text-gray-300 hover:text-[hsl(var(--neon-pink))] transition-all duration-300 font-medium group"
              whileHover={{ scale: 1.05 }}
            >
              الحافظة الذكية
              <div className="absolute -bottom-1 left-0 w-0 h-0.5 bg-gradient-to-r from-[hsl(var(--neon-pink))] to-rose-500 group-hover:w-full transition-all duration-300"></div>
            </motion.button>
            <motion.button 
              onClick={() => scrollTo('membership')}
              className="relative text-gray-300 hover:text-[hsl(var(--premium-gold))] transition-all duration-300 font-medium group"
              whileHover={{ scale: 1.05 }}
            >
              العضوية الذهبية
              <div className="absolute -bottom-1 left-0 w-0 h-0.5 bg-gradient-to-r from-[hsl(var(--premium-gold))] to-orange-500 group-hover:w-full transition-all duration-300"></div>
            </motion.button>
            <motion.button 
              onClick={() => scrollTo('contact')}
              className="relative text-gray-300 hover:text-emerald-400 transition-all duration-300 font-medium group"
              whileHover={{ scale: 1.05 }}
            >
              تواصل معنا
              <div className="absolute -bottom-1 left-0 w-0 h-0.5 bg-gradient-to-r from-emerald-500 to-green-500 group-hover:w-full transition-all duration-300"></div>
            </motion.button>
          </div>

          {/* User Profile */}
          <div className="flex items-center space-x-4">
            <Button
              variant="ghost"
              size="sm"
              className="relative glass-morphism hover-glow"
            >
              <i className="fas fa-bell text-gray-400"></i>
              <span className="absolute -top-1 -right-1 w-3 h-3 bg-red-500 rounded-full"></span>
            </Button>
            
            {/* User profile avatar with online status */}
            <div className="relative">
              <div className="w-10 h-10 rounded-full bg-gradient-to-br from-[hsl(var(--electric-blue))] to-[hsl(var(--deep-purple))] p-0.5">
                <div className="w-full h-full rounded-full bg-[hsl(var(--background))] flex items-center justify-center">
                  <i className="fas fa-user text-sm text-gray-300"></i>
                </div>
              </div>
              <div className="absolute -bottom-0.5 -right-0.5 w-3 h-3 bg-[hsl(var(--neon-green))] border-2 border-[hsl(var(--background))] rounded-full"></div>
            </div>
          </div>
        </div>
      </div>
    </motion.nav>
  );
}
