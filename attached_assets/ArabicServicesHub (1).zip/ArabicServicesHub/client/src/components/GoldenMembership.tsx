import { motion } from "framer-motion";
import { Button } from "@/components/ui/button";
import { GlassCard } from "@/components/ui/glass-card";
import { MEMBERSHIP_TIERS, GOLDEN_BENEFITS } from "@/lib/constants";

export function GoldenMembership() {
  return (
    <section id="membership" className="py-20 relative overflow-hidden">
      <div className="absolute inset-0 bg-gradient-to-br from-[hsl(var(--premium-gold))]/10 to-yellow-500/5"></div>
      <div className="max-w-7xl mx-auto px-6 relative z-10">
        <motion.div 
          className="text-center mb-16"
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8 }}
          viewport={{ once: true }}
        >
          <div className="inline-flex items-center glass-morphism rounded-full px-6 py-2 mb-6">
            <i className="fas fa-crown text-[hsl(var(--premium-gold))] mr-2"></i>
            <span className="text-[hsl(var(--premium-gold))] font-medium">Premium Experience</span>
          </div>
          <h2 className="text-4xl md:text-6xl font-black mb-6">
            <span className="text-gold-gradient">
              GOLDEN MEMBERSHIP
            </span>
          </h2>
          <p className="text-xl text-gray-300 max-w-3xl mx-auto">
            Unlock the ultimate security experience with exclusive features, priority support, and advanced AI capabilities
          </p>
        </motion.div>

        {/* Membership Tiers */}
        <motion.div 
          className="grid grid-cols-1 md:grid-cols-3 gap-8 mb-16"
          initial={{ opacity: 0 }}
          whileInView={{ opacity: 1 }}
          transition={{ duration: 0.8, staggerChildren: 0.2 }}
          viewport={{ once: true }}
        >
          {MEMBERSHIP_TIERS.map((tier, index) => (
            <motion.div
              key={tier.id}
              initial={{ opacity: 0, y: 30 }}
              whileInView={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.5, delay: index * 0.2 }}
              viewport={{ once: true }}
              className="relative"
            >
              {tier.popular && (
                <div className="absolute -top-4 left-1/2 transform -translate-x-1/2 bg-gradient-to-r from-[hsl(var(--electric-blue))] to-[hsl(var(--deep-purple))] rounded-full px-6 py-2 z-10">
                  <span className="text-sm font-bold text-white">MOST POPULAR</span>
                </div>
              )}
              
              {tier.id === 'golden' && (
                <div className="absolute -top-4 left-1/2 transform -translate-x-1/2 bg-gradient-to-r from-[hsl(var(--premium-gold))] to-orange-500 rounded-full px-6 py-2 z-10">
                  <span className="text-sm font-bold text-[hsl(var(--background))]">ULTIMATE LUXURY</span>
                </div>
              )}
              
              <GlassCard 
                className={`p-8 h-full ${tier.id === 'golden' ? 'border-2 border-[hsl(var(--premium-gold))]/30' : ''}`}
                variant={tier.id === 'golden' ? 'premium' : 'default'}
                hover
              >
                <div className={`text-center mb-8 ${tier.popular || tier.id === 'golden' ? 'mt-4' : ''}`}>
                  <div className={`w-16 h-16 mx-auto mb-4 bg-gradient-to-r ${tier.color} rounded-2xl flex items-center justify-center animate-glow`}>
                    <i className={`fas fa-${tier.icon} text-2xl text-white`}></i>
                  </div>
                  <h3 className="text-2xl font-bold mb-2">
                    {tier.id === 'golden' ? (
                      <span className="text-gold-gradient">{tier.name}</span>
                    ) : (
                      tier.name
                    )}
                  </h3>
                  <div className="text-4xl font-black mb-4">
                    <span className={tier.id === 'golden' ? 'text-gold-gradient' : tier.id === 'professional' ? 'text-gradient' : 'text-gray-400'}>
                      ${tier.price}
                    </span>
                    <span className="text-lg text-gray-500">/{tier.period}</span>
                  </div>
                  <p className="text-gray-400 text-sm">{tier.description}</p>
                </div>
                
                <ul className="space-y-4 mb-8">
                  {tier.features.map((feature, featureIndex) => (
                    <li key={featureIndex} className="flex items-center">
                      <i className={`fas fa-${tier.id === 'golden' ? 'crown' : 'check'} ${
                        tier.id === 'golden' ? 'text-[hsl(var(--premium-gold))]' : 
                        tier.id === 'professional' ? 'text-[hsl(var(--electric-blue))]' : 
                        'text-[hsl(var(--neon-green))]'
                      } mr-3`}></i>
                      <span className="text-sm">{feature}</span>
                    </li>
                  ))}
                </ul>
                
                <Button 
                  className={`w-full rounded-xl py-3 font-semibold hover-glow transition-all duration-300 ${tier.buttonClass}`}
                  size="lg"
                >
                  {tier.buttonText}
                </Button>
              </GlassCard>
            </motion.div>
          ))}
        </motion.div>

        {/* Golden Benefits */}
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8 }}
          viewport={{ once: true }}
        >
          <GlassCard className="p-8 border-2 border-[hsl(var(--premium-gold))]/20" variant="premium">
            <div className="text-center mb-8">
              <h3 className="text-3xl font-bold mb-4">
                <span className="text-gold-gradient">
                  Exclusive Golden Benefits
                </span>
              </h3>
              <p className="text-gray-400">Unlock premium features available only to Golden Elite members</p>
            </div>
            
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              {GOLDEN_BENEFITS.map((benefit, index) => (
                <motion.div
                  key={index}
                  className="glass-morphism rounded-xl p-6 text-center hover-glow"
                  initial={{ opacity: 0, y: 20 }}
                  whileInView={{ opacity: 1, y: 0 }}
                  transition={{ duration: 0.5, delay: index * 0.1 }}
                  viewport={{ once: true }}
                  whileHover={{ scale: 1.05 }}
                >
                  <div className="w-12 h-12 mx-auto mb-4 bg-gradient-to-r from-[hsl(var(--premium-gold))] to-orange-400 rounded-xl flex items-center justify-center">
                    <i className={`fas fa-${benefit.icon} text-lg text-[hsl(var(--background))]`}></i>
                  </div>
                  <h4 className="font-bold mb-2">{benefit.title}</h4>
                  <p className="text-sm text-gray-400">{benefit.description}</p>
                </motion.div>
              ))}
            </div>
          </GlassCard>
        </motion.div>
      </div>
    </section>
  );
}
