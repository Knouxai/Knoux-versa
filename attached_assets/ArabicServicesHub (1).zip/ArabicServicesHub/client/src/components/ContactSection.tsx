import { useState } from "react";
import { motion } from "framer-motion";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { GlassCard } from "@/components/ui/glass-card";
import { useToast } from "@/hooks/use-toast";
import { useMutation } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";

interface ContactFormData {
  name: string;
  email: string;
  inquiryType: string;
  message: string;
}

export function ContactSection() {
  const [formData, setFormData] = useState<ContactFormData>({
    name: '',
    email: '',
    inquiryType: '',
    message: ''
  });
  const { toast } = useToast();

  const submitMutation = useMutation({
    mutationFn: async (data: ContactFormData) => {
      return apiRequest('POST', '/api/contact', data);
    },
    onSuccess: () => {
      toast({
        title: "Message Sent Successfully",
        description: "Thank you for contacting us. We'll get back to you within 24 hours.",
      });
      setFormData({ name: '', email: '', inquiryType: '', message: '' });
    },
    onError: (error) => {
      toast({
        title: "Failed to Send Message", 
        description: error.message,
        variant: "destructive",
      });
    },
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!formData.name || !formData.email || !formData.inquiryType || !formData.message) {
      toast({
        title: "Missing Information",
        description: "Please fill in all required fields.",
        variant: "destructive",
      });
      return;
    }
    submitMutation.mutate(formData);
  };

  return (
    <section id="contact" className="py-20 relative">
      <div className="max-w-4xl mx-auto px-6">
        <motion.div 
          className="text-center mb-16"
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8 }}
          viewport={{ once: true }}
        >
          <h2 className="text-5xl font-bold text-gradient mb-6">Contact Us</h2>
          <p className="text-xl text-gray-300">
            Our support team is available 24/7 to help you with all your security needs
          </p>
        </motion.div>
        
        <div className="grid md:grid-cols-2 gap-12">
          {/* Contact Form */}
          <motion.div
            initial={{ opacity: 0, x: -30 }}
            whileInView={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.8 }}
            viewport={{ once: true }}
          >
            <GlassCard className="p-8">
              <h3 className="text-2xl font-bold mb-6 text-[hsl(var(--electric-blue))]">Send Message</h3>
              <form onSubmit={handleSubmit} className="space-y-6">
                <Input
                  placeholder="Full Name"
                  value={formData.name}
                  onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                  className="glass-morphism bg-transparent border-white/20 focus:border-[hsl(var(--electric-blue))]/50"
                  required
                />
                <Input
                  type="email"
                  placeholder="Email Address"
                  value={formData.email}
                  onChange={(e) => setFormData({ ...formData, email: e.target.value })}
                  className="glass-morphism bg-transparent border-white/20 focus:border-[hsl(var(--electric-blue))]/50"
                  required
                />
                <Select value={formData.inquiryType} onValueChange={(value) => setFormData({ ...formData, inquiryType: value })}>
                  <SelectTrigger className="glass-morphism bg-transparent border-white/20 focus:border-[hsl(var(--electric-blue))]/50">
                    <SelectValue placeholder="Inquiry Type" />
                  </SelectTrigger>
                  <SelectContent className="glass-dark border-white/20">
                    <SelectItem value="support">Technical Support</SelectItem>
                    <SelectItem value="sales">Sales Inquiry</SelectItem>
                    <SelectItem value="partnership">Partnership</SelectItem>
                    <SelectItem value="other">Other</SelectItem>
                  </SelectContent>
                </Select>
                <Textarea
                  placeholder="Your Message"
                  rows={4}
                  value={formData.message}
                  onChange={(e) => setFormData({ ...formData, message: e.target.value })}
                  className="glass-morphism bg-transparent border-white/20 focus:border-[hsl(var(--electric-blue))]/50 resize-none"
                  required
                />
                <Button 
                  type="submit" 
                  className="w-full bg-gradient-to-r from-[hsl(var(--electric-blue))] to-[hsl(var(--deep-purple))] py-3 rounded-xl font-semibold hover-glow transition-all"
                  disabled={submitMutation.isPending}
                >
                  {submitMutation.isPending ? (
                    <>
                      <i className="fas fa-spinner fa-spin mr-2"></i>
                      Sending...
                    </>
                  ) : (
                    'Send Message'
                  )}
                </Button>
              </form>
            </GlassCard>
          </motion.div>
          
          {/* Contact Info */}
          <motion.div 
            className="space-y-8"
            initial={{ opacity: 0, x: 30 }}
            whileInView={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.8 }}
            viewport={{ once: true }}
          >
            {[
              {
                icon: 'whatsapp',
                iconType: 'fab',
                title: 'WhatsApp',
                content: '+1 (555) 123-4567',
                description: 'Available for instant support 24/7',
                color: 'text-[hsl(var(--premium-gold))]'
              },
              {
                icon: 'envelope',
                iconType: 'fas',
                title: 'Email',
                content: 'support@knoux.com',
                description: 'Response within 30 minutes for Golden members',
                color: 'text-[hsl(var(--electric-blue))]'
              },
              {
                icon: 'headset',
                iconType: 'fas',
                title: 'Live Support',
                content: 'Available on website',
                description: 'Direct chat with security experts',
                color: 'text-[hsl(var(--neon-green))]'
              }
            ].map((contact, index) => (
              <motion.div
                key={index}
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.5, delay: index * 0.2 }}
                viewport={{ once: true }}
              >
                <GlassCard className="p-6 hover-glow">
                  <div className="flex items-center mb-4">
                    <div className={`${contact.color} text-2xl mr-4`}>
                      <i className={`${contact.iconType} fa-${contact.icon}`}></i>
                    </div>
                    <div>
                      <h4 className="font-bold">{contact.title}</h4>
                      <p className="text-gray-300">{contact.content}</p>
                    </div>
                  </div>
                  <p className="text-sm text-gray-400">{contact.description}</p>
                </GlassCard>
              </motion.div>
            ))}
          </motion.div>
        </div>
      </div>
    </section>
  );
}
