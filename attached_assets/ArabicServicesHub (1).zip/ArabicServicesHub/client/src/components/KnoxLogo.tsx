import { motion } from "framer-motion";

interface KnoxLogoProps {
  size?: 'sm' | 'md' | 'lg' | 'xl';
  animated?: boolean;
  showText?: boolean;
  className?: string;
}

export function KnoxLogo({ size = 'md', animated = true, showText = true, className = '' }: KnoxLogoProps) {
  const sizes = {
    sm: { icon: 'w-8 h-8', text: 'text-lg' },
    md: { icon: 'w-12 h-12', text: 'text-2xl' },
    lg: { icon: 'w-16 h-16', text: 'text-3xl' },
    xl: { icon: 'w-24 h-24', text: 'text-5xl' }
  };

  const logoVariants = {
    initial: { scale: 0.8, opacity: 0 },
    animate: { 
      scale: 1, 
      opacity: 1,
      transition: { duration: 0.8, ease: "easeOut" }
    },
    hover: { 
      scale: 1.05,
      transition: { duration: 0.3 }
    }
  };

  const glowVariants = {
    animate: {
      boxShadow: [
        "0 0 20px hsl(var(--electric-blue) / 0.4)",
        "0 0 40px hsl(var(--electric-blue) / 0.8), 0 0 60px hsl(var(--deep-purple) / 0.4)",
        "0 0 20px hsl(var(--electric-blue) / 0.4)"
      ],
      transition: { duration: 2, repeat: Infinity, ease: "easeInOut" }
    }
  };

  const LogoIcon = () => (
    <motion.div 
      className={`${sizes[size].icon} relative rounded-2xl bg-gradient-to-br from-[hsl(var(--electric-blue))] via-[hsl(var(--deep-purple))] to-[hsl(var(--neon-pink))] flex items-center justify-center overflow-hidden`}
      variants={animated ? glowVariants : {}}
      animate={animated ? "animate" : {}}
    >
      {/* القلب الكمي للشعار */}
      <div className="absolute inset-0 bg-gradient-to-br from-transparent via-white/10 to-transparent"></div>
      
      {/* الرمز المركزي */}
      <div className="relative z-10 flex items-center justify-center">
        <motion.svg 
          viewBox="0 0 40 40" 
          className="w-3/4 h-3/4 text-white"
          initial={animated ? { rotate: 0 } : {}}
          animate={animated ? { rotate: [0, 360] } : {}}
          transition={animated ? { duration: 20, repeat: Infinity, ease: "linear" } : {}}
        >
          {/* الحلقة الخارجية الكمية */}
          <circle 
            cx="20" cy="20" r="18" 
            fill="none" 
            stroke="currentColor" 
            strokeWidth="1" 
            strokeDasharray="4 4"
            opacity="0.6"
          />
          
          {/* الحلقة الوسطى */}
          <circle 
            cx="20" cy="20" r="12" 
            fill="none" 
            stroke="currentColor" 
            strokeWidth="1.5" 
            strokeDasharray="2 2"
            opacity="0.8"
          />
          
          {/* الرمز المركزي - حرف K مطور */}
          <path 
            d="M12 8 L12 32 M12 20 L28 8 M12 20 L28 32" 
            stroke="currentColor" 
            strokeWidth="2.5" 
            strokeLinecap="round" 
            strokeLinejoin="round"
            fill="none"
          />
          
          {/* نقاط الكم */}
          <motion.circle cx="8" cy="12" r="1" fill="currentColor" 
            animate={animated ? { opacity: [0.3, 1, 0.3] } : {}}
            transition={animated ? { duration: 2, repeat: Infinity, delay: 0 } : {}}
          />
          <motion.circle cx="32" cy="16" r="1" fill="currentColor"
            animate={animated ? { opacity: [0.3, 1, 0.3] } : {}}
            transition={animated ? { duration: 2, repeat: Infinity, delay: 0.5 } : {}}
          />
          <motion.circle cx="8" cy="28" r="1" fill="currentColor"
            animate={animated ? { opacity: [0.3, 1, 0.3] } : {}}
            transition={animated ? { duration: 2, repeat: Infinity, delay: 1 } : {}}
          />
          <motion.circle cx="32" cy="24" r="1" fill="currentColor"
            animate={animated ? { opacity: [0.3, 1, 0.3] } : {}}
            transition={animated ? { duration: 2, repeat: Infinity, delay: 1.5 } : {}}
          />
        </motion.svg>
      </div>
      
      {/* التأثير الضوئي */}
      <div className="absolute -top-1 -right-1 w-4 h-4 bg-[hsl(var(--premium-gold))] rounded-full animate-pulse opacity-90"></div>
    </motion.div>
  );

  return (
    <motion.div 
      className={`flex items-center space-x-3 ${className}`}
      variants={animated ? logoVariants : {}}
      initial={animated ? "initial" : {}}
      animate={animated ? "animate" : {}}
      whileHover={animated ? "hover" : {}}
    >
      <LogoIcon />
      
      {showText && (
        <div className="flex flex-col">
          <motion.h1 
            className={`${sizes[size].text} font-black text-gradient leading-tight`}
            animate={animated ? { 
              backgroundPosition: ["0% 50%", "100% 50%", "0% 50%"] 
            } : {}}
            transition={animated ? { 
              duration: 4, 
              repeat: Infinity, 
              ease: "linear" 
            } : {}}
          >
            KNOUX
          </motion.h1>
          {size !== 'sm' && (
            <p className="text-xs text-gray-400 font-medium tracking-wider">
              UltraEncrypt Pro
            </p>
          )}
        </div>
      )}
    </motion.div>
  );
}