import { cn } from "@/lib/utils";
import { motion } from "framer-motion";

interface GlassCardProps {
  children: React.ReactNode;
  className?: string;
  variant?: "default" | "dark" | "premium";
  hover?: boolean;
  animate?: boolean;
}

export function GlassCard({ 
  children, 
  className, 
  variant = "default", 
  hover = true,
  animate = false 
}: GlassCardProps) {
  const baseClasses = "rounded-2xl border";
  
  const variants = {
    default: "glass-morphism",
    dark: "glass-dark",
    premium: "glass-morphism premium-shadow border-[hsl(var(--premium-gold))] border-opacity-30"
  };
  
  const hoverClasses = hover ? "hover-glow transition-all duration-300 hover:scale-105" : "";
  
  const cardClasses = cn(
    baseClasses,
    variants[variant],
    hoverClasses,
    className
  );

  if (animate) {
    return (
      <motion.div
        className={cardClasses}
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.5 }}
        whileHover={{ y: -5, scale: 1.02 }}
      >
        {children}
      </motion.div>
    );
  }

  return (
    <div className={cardClasses}>
      {children}
    </div>
  );
}
